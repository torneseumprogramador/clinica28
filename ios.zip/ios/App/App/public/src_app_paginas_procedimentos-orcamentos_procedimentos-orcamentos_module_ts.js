"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_paginas_procedimentos-orcamentos_procedimentos-orcamentos_module_ts"],{

/***/ 3627:
/*!*********************************************************************************************!*\
  !*** ./src/app/paginas/procedimentos-orcamentos/procedimentos-orcamentos-routing.module.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProcedimentosOrcamentosPageRoutingModule": () => (/* binding */ ProcedimentosOrcamentosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _procedimentos_orcamentos_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./procedimentos-orcamentos.page */ 1270);




const routes = [
    {
        path: '',
        component: _procedimentos_orcamentos_page__WEBPACK_IMPORTED_MODULE_0__.ProcedimentosOrcamentosPage
    }
];
let ProcedimentosOrcamentosPageRoutingModule = class ProcedimentosOrcamentosPageRoutingModule {
};
ProcedimentosOrcamentosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProcedimentosOrcamentosPageRoutingModule);



/***/ }),

/***/ 4660:
/*!*************************************************************************************!*\
  !*** ./src/app/paginas/procedimentos-orcamentos/procedimentos-orcamentos.module.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProcedimentosOrcamentosPageModule": () => (/* binding */ ProcedimentosOrcamentosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _procedimentos_orcamentos_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./procedimentos-orcamentos-routing.module */ 3627);
/* harmony import */ var _procedimentos_orcamentos_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./procedimentos-orcamentos.page */ 1270);
/* harmony import */ var src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/componentes/carrinho/carrinho.component */ 8752);
/* harmony import */ var src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/componentes/footer/footer.component */ 202);
/* harmony import */ var src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/componentes/header/header.component */ 4944);
/* harmony import */ var src_app_componentes_modal_procedimento_modal_procedimento_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/componentes/modal-procedimento/modal-procedimento.component */ 6907);
/* harmony import */ var src_app_pipes_formata_cpf_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/pipes/formata-cpf.pipe */ 5601);
/* harmony import */ var src_app_pipes_formata_rg_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/pipes/formata-rg.pipe */ 8088);
/* harmony import */ var src_app_pipes_formata_sexo_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/pipes/formata-sexo.pipe */ 1089);
/* harmony import */ var src_app_pipes_formata_telefone_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/pipes/formata-telefone.pipe */ 683);















let ProcedimentosOrcamentosPageModule = class ProcedimentosOrcamentosPageModule {
};
ProcedimentosOrcamentosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_12__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.IonicModule,
            _procedimentos_orcamentos_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProcedimentosOrcamentosPageRoutingModule
        ],
        declarations: [_procedimentos_orcamentos_page__WEBPACK_IMPORTED_MODULE_1__.ProcedimentosOrcamentosPage,
            src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_4__.HeaderComponent, src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterComponent, src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_2__.CarrinhoComponent,
            src_app_componentes_modal_procedimento_modal_procedimento_component__WEBPACK_IMPORTED_MODULE_5__.ModalProcedimentoComponent,
            src_app_pipes_formata_sexo_pipe__WEBPACK_IMPORTED_MODULE_8__.FormataSexoPipe, src_app_pipes_formata_cpf_pipe__WEBPACK_IMPORTED_MODULE_6__.FormataCpfPipe, src_app_pipes_formata_rg_pipe__WEBPACK_IMPORTED_MODULE_7__.FormataRgPipe, src_app_pipes_formata_telefone_pipe__WEBPACK_IMPORTED_MODULE_9__.FormataTelefonePipe]
    })
], ProcedimentosOrcamentosPageModule);



/***/ }),

/***/ 1270:
/*!***********************************************************************************!*\
  !*** ./src/app/paginas/procedimentos-orcamentos/procedimentos-orcamentos.page.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProcedimentosOrcamentosPage": () => (/* binding */ ProcedimentosOrcamentosPage)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _procedimentos_orcamentos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./procedimentos-orcamentos.page.html?ngResource */ 1076);
/* harmony import */ var _procedimentos_orcamentos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./procedimentos-orcamentos.page.scss?ngResource */ 6623);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_services_carrinho_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/carrinho.service */ 2136);
/* harmony import */ var src_app_services_cepService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/cepService */ 7326);
/* harmony import */ var src_app_services_clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/clinicaProcedimentoService */ 4731);
/* harmony import */ var src_app_services_erroService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/erroService */ 8592);
/* harmony import */ var src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/pacienteService */ 8839);
/* harmony import */ var src_app_services_scrollService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/scrollService */ 7093);
/* harmony import */ var src_app_services_tempService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/tempService */ 6685);
/* harmony import */ var src_app_services_modalService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/modalService */ 4704);















let ProcedimentosOrcamentosPage = class ProcedimentosOrcamentosPage {
  constructor(http, route, router, carrinhoService) {
    this.http = http;
    this.router = router;
    this.carrinhoService = carrinhoService;
    this.cadastro = false;
    this.orcamentosSelecionados = [];
    this.msg_procedimentos = '';
    route.params.subscribe(val => {
      this.carrinhoService.carregaQuantidade();
    });

    if (!src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_7__.PacienteServico.logado()) {
      this.router.navigateByUrl('/login');
    }
  }

  ngOnInit() {
    this.orcamentosSelecionados = src_app_services_tempService__WEBPACK_IMPORTED_MODULE_9__.TempService.getTempObjects('orcamentosSelecionados');

    if (!this.paciente) {
      this.paciente = src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_7__.PacienteServico.getSessao();
      this.paciente.rg = undefined;
    }

    this.cpf = this.paciente?.cpf;
  }

  preencheCep() {
    new src_app_services_cepService__WEBPACK_IMPORTED_MODULE_4__.CepServico(this.http).set(this.paciente);
  }

  buscaCPF() {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.mensagem = '';
      _this.paciente = undefined;

      try {
        const pacientes = yield new src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_7__.PacienteServico(_this.http).porCPF(_this.cpf);

        if (pacientes.length > 0) {
          _this.paciente = pacientes[0];

          if (!_this.paciente.cep) {
            _this.telaSalvarCadastro();
          }
        } else {
          _this.mensagem = 'Paciente não encontrado!';
        }
      } catch (e) {
        _this.mensagem = src_app_services_erroService__WEBPACK_IMPORTED_MODULE_6__.ErroServico.mensagemErro(e);
      }
    })();
  }

  naoEncontrado() {
    return this.mensagem.match(/não encontrado/) != null ? true : false;
  }

  telaSalvarCadastro() {
    if (!this.paciente || !this.paciente.id) {
      this.paciente = {};
      this.paciente.cpf = this.cpf;
    }

    this.cadastro = true;
    this.mensagem_cadastro = '';
  }

  voltar() {
    var _this2 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.paciente = {};
      _this2.cadastro = false;
    })();
  }

  cadastrar() {
    var _this3 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.mensagem = '';
      _this3.mensagem_cadastro = '';

      if (!_this3.paciente.nome || _this3.paciente.nome === '') {
        _this3.mensagem_cadastro = 'Nome obrigatório';
        return;
      }

      if (!_this3.paciente.cpf || _this3.paciente.cpf === '') {
        _this3.mensagem_cadastro = 'CPF obrigatório';
        return;
      }

      if (!_this3.paciente.sexo) {
        _this3.mensagem_cadastro = 'Sexo obrigatório';
        return;
      }

      if (!_this3.paciente.nome_mae || _this3.paciente.nome_mae === '') {
        _this3.mensagem_cadastro = 'Nome da mãe obrigatório';
        return;
      }

      if (!_this3.paciente.fone || _this3.paciente.fone === '') {
        _this3.mensagem_cadastro = 'Telefone obrigatório';
        return;
      }

      if (!_this3.paciente.endereco || _this3.paciente.endereco === '') {
        _this3.mensagem_cadastro = 'Endereço obrigatório';
        return;
      }

      if (!_this3.paciente.numero || _this3.paciente.numero === '') {
        _this3.mensagem_cadastro = 'Número obrigatório';
        return;
      }

      if (!_this3.paciente.bairro || _this3.paciente.bairro === '') {
        _this3.mensagem_cadastro = 'Bairro obrigatório';
        return;
      }

      if (!_this3.paciente.cidade || _this3.paciente.cidade === '') {
        _this3.mensagem_cadastro = 'Cidade obrigatório';
        return;
      }

      if (!_this3.paciente.uf || _this3.paciente.uf === '') {
        _this3.mensagem_cadastro = 'Estado obrigatório';
        return;
      }

      try {
        _this3.paciente.paciente_id_titular = src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_7__.PacienteServico.getSessao().id;
        _this3.paciente = yield new src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_7__.PacienteServico(_this3.http).salvar(_this3.paciente);
        _this3.cadastro = false;
        _this3.cpf = _this3.paciente.cpf;
      } catch (e) {
        _this3.mensagem_cadastro = src_app_services_erroService__WEBPACK_IMPORTED_MODULE_6__.ErroServico.mensagemErro(e);
        src_app_services_scrollService__WEBPACK_IMPORTED_MODULE_8__.ScrollServico.scroll('mensagemErro');
      }
    })();
  }

  addCarrinho() {
    var _this4 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        const clinicaProcedimentoSalvar = {};
        clinicaProcedimentoSalvar.paciente_logado_id = src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_7__.PacienteServico.getSessao().id;
        clinicaProcedimentoSalvar.paciente_id = _this4.paciente.id;
        clinicaProcedimentoSalvar.orcamentosSelecionados = _this4.orcamentosSelecionados;
        yield new src_app_services_clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_5__.ClinicaProcedimentoService(_this4.http).salvar(clinicaProcedimentoSalvar);
        src_app_services_tempService__WEBPACK_IMPORTED_MODULE_9__.TempService.clearTempObjects();
        src_app_services_modalService__WEBPACK_IMPORTED_MODULE_10__.ModalService.show('Carrinho', 'Dado inserido com sucesso!', undefined, true, false, () => {
          window.location.href = '/carrinho';
        });
      } catch (e) {
        _this4.mensagem_cadastro = src_app_services_erroService__WEBPACK_IMPORTED_MODULE_6__.ErroServico.mensagemErro(e);
        src_app_services_scrollService__WEBPACK_IMPORTED_MODULE_8__.ScrollServico.scroll('mensagemErro');
      }
    })();
  }

  valorTotal() {
    if (this.orcamentosSelecionados.length === 0) {
      return 0;
    }

    let valor = 0;
    this.orcamentosSelecionados.forEach(orcamento => {
      valor = Number(valor) + Number(orcamento.procedimento_valor);
    });
    return valor;
  }

  updateSelecionados(orcamentos) {
    this.orcamentosSelecionados = orcamentos;
    src_app_services_tempService__WEBPACK_IMPORTED_MODULE_9__.TempService.setTempObjects('orcamentosSelecionados', this.orcamentosSelecionados);
  }

};

ProcedimentosOrcamentosPage.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpClient
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.Router
}, {
  type: src_app_services_carrinho_service__WEBPACK_IMPORTED_MODULE_3__.CarrinhoService
}];

ProcedimentosOrcamentosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.Component)({
  selector: 'app-procedimentos-orcamentos',
  template: _procedimentos_orcamentos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_procedimentos_orcamentos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ProcedimentosOrcamentosPage);


/***/ }),

/***/ 6623:
/*!************************************************************************************************!*\
  !*** ./src/app/paginas/procedimentos-orcamentos/procedimentos-orcamentos.page.scss?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcm9jZWRpbWVudG9zLW9yY2FtZW50b3MucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 1076:
/*!************************************************************************************************!*\
  !*** ./src/app/paginas/procedimentos-orcamentos/procedimentos-orcamentos.page.html?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header></app-header>\n\n<ion-content [fullscreen]=\"true\">\n  <section class=\"main-area text-center\">\n    <div class=\"titulo-local\">\n      <div class=\"texto\">Confirme as Informações</div>\n      <div class=\"icon-marca\">\n        <img src=\"assets/images/marca/elemento-branco.png\" alt=\"elemento\">\n      </div>\n    </div>\n\n    <div id=\"cadastro\">\n      <div class=\"checkout-form\">\n        <div style=\"text-align: center;\">\n          <h1 class=\"mt-4 titulo-valor\"> Valor total</h1>\n          <div class=\"valor-total\"><h1>{{valorTotal() | currency}}</h1></div>\n        </div>\n      </div>\n\n\n      <div *ngIf=\"!cadastro\">\n        <div id=\"informe-cpf\">\n          <div class=\"form-group\">\n            <div class=\"dados-paciente\">\n              Informe o CPF do paciente e CLIQUE em <br>\n              <b>confirmar</b> para fazer o agendamento.\n            </div>\n\n            <input type=\"text\" [(ngModel)]=\"cpf\" class=\"box\" id=\"cpf\" name=\"cpf\" [patterns]=\"customPatterns\" mask=\"000.000.000-00\" placeholder=\"Digite seu CPF\">\n            <div class=\"icon-input\">\n              <img src=\"assets/images/perfil/65937.png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"actions text-center\">\n            <button type=\"button\" class=\"btn btn-warning\" (click)=\"buscaCPF()\">Confirmar</button>\n          </div>\n        </div>\n\n        <div *ngIf=\"mensagem\" class=\"alert alert-warning\" style=\"margin-top: 20px;\">\n          <div [innerHTML]=\"mensagem\" ></div>\n          <div *ngIf=\"naoEncontrado()\">\n            Vamos iniciar o seu cadastro ? <br>\n            <button class=\"btn btn-primary\" (click)=\"telaSalvarCadastro()\">Clique aqui para iniciar</button>\n          </div>\n        </div>\n\n        <div id=\"dadosPaciente\" *ngIf=\"paciente && paciente.id && paciente.id > 0 && paciente.cep\" style=\"padding-top: 20px;\">\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.nome\" class=\"box\" id=\"nome\" name=\"nome\" placeholder=\"Digite seu nome\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/name.png\" alt=\"name\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.rg\" [patterns]=\"customPatterns\" mask=\"00.000.000-00\" class=\"box\"\n              id=\"rg\" name=\"rg\" placeholder=\"Digite seu RG\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/65937.png\" alt=\"65937\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <select [(ngModel)]=\"paciente.sexo\" class=\"box\" id=\"sexo\" name=\"sexo\">\n              <option value=\"undefined\">Sexo</option>\n              <option value=\"1\">Feminino</option>\n              <option value=\"2\">Masculino</option>\n            </select>\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/505972.png\" alt=\"505972\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.nome_mae\" class=\"box\" name=\"nome_mae\" id=\"nome_mae\"\n              placeholder=\"Digite nome da mãe\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/3557853.png\" alt=\"3557853\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"date\" [(ngModel)]=\"paciente.data_nascimento\" class=\"box\" name=\"data_nascimento\" id=\"data_nascimento\"\n              placeholder=\"Digite seu data nascimento\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/2458562.png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.fone\" class=\"box\" [patterns]=\"customPatterns\"\n              mask=\"(00) 00000-0000\" id=\"fone\" name=\"fone\" placeholder=\"Digite seu telefone\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/celular.png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.fone2\" class=\"box\" [patterns]=\"customPatterns\"\n              mask=\"(00) 00000-0000\" id=\"fone2\" name=\"fone2\" placeholder=\"Digite seu telefone 2\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/celular.png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.endereco\" name=\"endereco\" class=\"box\" id=\"endereco\"\n              placeholder=\"Digite seu endereço\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.numero\" name=\"numero\" maxlength=\"10\" class=\"box\" id=\"numero\"\n              placeholder=\"Digite seu número\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.cep\" name=\"cep\" (blur)=\"preencheCep()\" [patterns]=\"customPatterns\" mask=\"00000-000\" class=\"box\"\n              id=\"cep\" placeholder=\"Digite seu CEP\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.bairro\" name=\"bairro\" class=\"box\" id=\"bairro\" placeholder=\"Digite seu bairro\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.cidade\" name=\"cidade\" class=\"box\" id=\"cidade\" placeholder=\"Digite seu cidade\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.uf\" name=\"uf\" class=\"box\" id=\"uf\" placeholder=\"Digite seu estado\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n            </div>\n          </div>\n\n          <div id=\"mensagemErro\" *ngIf=\"mensagem_cadastro\" [innerHTML]=\"mensagem_cadastro\" class=\"alert alert-warning\"\n            style=\"margin-top: 20px;\"></div>\n\n          <div class=\"actions text-center add-carrinho\" (click)=\"addCarrinho()\">\n            <button type=\"button\" class=\"btn btn-warning\">Adicione ao Carrinho</button>\n            <div class=\"icon-flutuante\">\n              <img src=\"assets/images/perfil/icon-carrinho-de-compras-de-design-xadrez.png\" alt=\"\">\n            </div>\n          </div>\n        </div>\n      </div>\n\n      <div *ngIf=\"cadastro\">\n        <h1>Informar dados do paciente</h1>\n        <br>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.nome\" class=\"box\" id=\"nome\" name=\"name\" placeholder=\"Nome Completo\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/name.png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.rg\" [patterns]=\"customPatterns\" mask=\"00.000.000-00\" class=\"box\"\n            id=\"rg\" name=\"rg\" placeholder=\"RG\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/65937.png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <select [(ngModel)]=\"paciente.sexo\" class=\"box\" id=\"sexo\" name=\"sexo\">\n            <option value=\"undefined\">Sexo</option>\n            <option value=\"1\">Feminino</option>\n            <option value=\"2\">Masculino</option>\n          </select>\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/505972.png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.nome_mae\" class=\"box\" name=\"nome_mae\" id=\"nome_mae\"\n            placeholder=\"NOME DA MÃE\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/3557853.png\" alt=\"3557853\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"date\" [(ngModel)]=\"paciente.data_nascimento\" class=\"box\" name=\"data_nascimento\" id=\"data_nascimento\"\n            placeholder=\"Data de Nascimento\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/2458562.png\" alt=\"2458562\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.fone\" class=\"box\" [patterns]=\"customPatterns\"\n            mask=\"(00) 00000-0000\" id=\"fone\" name=\"fone\" placeholder=\"Telefone/Whatsapp\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/celular.png\" alt=\"celular\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.fone2\" class=\"box\" [patterns]=\"customPatterns\"\n            mask=\"(00) 00000-0000\" id=\"fone2\" name=\"fone2\" placeholder=\"Telefone/Whatsapp\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/celular.png\" alt=\"celular\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.endereco\" name=\"endereco\" class=\"box\" id=\"endereco\"\n            placeholder=\"Endereço\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.numero\" name=\"numero\" maxlength=\"10\" class=\"box\" id=\"numero\"\n            placeholder=\"Número\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.cep\" name=\"cep\" (blur)=\"preencheCep()\" [patterns]=\"customPatterns\" mask=\"00000-000\" class=\"box\"\n            id=\"cep\" placeholder=\"CEP\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.bairro\" name=\"bairro\" class=\"box\" id=\"bairro\" placeholder=\"Bairro\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.cidade\" name=\"cidade\" class=\"box\" id=\"cidade\" placeholder=\"Cidade\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.uf\" name=\"uf\" class=\"box\" id=\"uf\" placeholder=\"Estado\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n          </div>\n        </div>\n\n        <div id=\"mensagemErro\" *ngIf=\"mensagem_cadastro\" [innerHTML]=\"mensagem_cadastro\" class=\"alert alert-warning\"\n            style=\"margin-top: 20px;\"></div>\n\n        <br>\n\n        <div class=\"actions text-center\">\n          <button type=\"button\" class=\"btn btn-warning\" style=\"padding: 5px 33px; margin-bottom: 10px;\" (click)=\"cadastrar()\">Salvar</button><br>\n          <button type=\"button\" class=\"btn btn-primary\" (click)=\"voltar()\">Cancelar</button>\n        </div>\n      </div>\n    </div>\n\n    <div id=\"procedimentos\">\n      <div *ngIf=\"msg_procedimentos\" class=\"alert alert-warning\">{{msg_procedimentos}}</div>\n      <div id=\"horarios\">\n        <div class=\"grupo-horarios\">\n          <div class=\"cabecalho-horarios\" style=\"padding: 10px; text-align: end;\">\n            <div class=\"options\">PROCEDIMENTO / PACIENTE <br> DATA DE VALIDADE / VALOR</div>\n          </div>\n          <div *ngFor=\"let item of orcamentosSelecionados\" style=\"border-bottom: 8px solid #fff;\">\n            <table style=\"width: 100%;\">\n              <tr style=\"border-bottom: 1px solid #fff;\">\n                <td style=\"background-color: #707070;width: 25%;\">\n                  <div class=\"horario\" style=\"display: inline-block;border: none;\">\n                    <div class=\"informacoes intercalacao\">\n                      <div class=\"local intercalacao\">\n                        <p>Selecionar</p>\n                        <input type=\"checkbox\" checked=\"{{item.checked}}\" (click)=\"seleciona(item, $event.target)\" name=\"selecionaProcedimento\" >\n                      </div>\n                    </div>\n                  </div>\n                </td>\n                <td style=\"background-color: #707070;\">\n                  <div class=\"horario\">\n                    <div class=\"informacoes\">\n                      <div class=\"local\" style=\"background-color: #ff5a00;font-size: 14px;\">\n                        {{item.procedimento_nome}}\n                      </div>\n                    </div>\n                  </div>\n\n                  <div class=\"horario\">\n                    <div class=\"informacoes\">\n                      <div class=\"local\">\n                        {{item.paciente_nome}}\n                      </div>\n                    </div>\n                  </div>\n\n                  <div class=\"horario\">\n                    <div class=\"informacoes\">\n                      <div class=\"local\" style=\"border-radius: 0;\">\n                        {{item.datavalidade | date: 'dd/MM/yyyy'}}\n                      </div>\n                    </div>\n                    <div class=\"informacoes\">\n                      <div class=\"local\" style=\"border-radius: 0;\">\n                        {{item.procedimento_valor | currency : 'BRL'}}\n                      </div>\n                    </div>\n                  </div>\n                </td>\n              </tr>\n            </table>\n          </div>\n        </div>\n      </div>\n    </div>\n\n  </section>\n\n\n</ion-content>\n\n<app-footer></app-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_paginas_procedimentos-orcamentos_procedimentos-orcamentos_module_ts.js.map