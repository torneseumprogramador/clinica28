"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_paginas_profissional_perfil_perfil_module_ts-src_app_services_loadService_ts"],{

/***/ 4140:
/*!**********************************************************************!*\
  !*** ./src/app/paginas/profissional/perfil/perfil-routing.module.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PerfilPageRoutingModule": () => (/* binding */ PerfilPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _perfil_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./perfil.page */ 8412);




const routes = [
    {
        path: '',
        component: _perfil_page__WEBPACK_IMPORTED_MODULE_0__.PerfilPage
    }
];
let PerfilPageRoutingModule = class PerfilPageRoutingModule {
};
PerfilPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PerfilPageRoutingModule);



/***/ }),

/***/ 4479:
/*!**************************************************************!*\
  !*** ./src/app/paginas/profissional/perfil/perfil.module.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PerfilPageModule": () => (/* binding */ PerfilPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _perfil_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./perfil-routing.module */ 4140);
/* harmony import */ var _perfil_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./perfil.page */ 8412);
/* harmony import */ var src_app_componentes_profissional_header_profissional_header_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/componentes/profissional-header/profissional-header.component */ 8789);
/* harmony import */ var src_app_componentes_profissional_footer_profissional_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/componentes/profissional-footer/profissional-footer.component */ 5043);
/* harmony import */ var ngx_mask__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-mask */ 446);










let PerfilPageModule = class PerfilPageModule {
};
PerfilPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            ngx_mask__WEBPACK_IMPORTED_MODULE_7__.NgxMaskModule.forRoot(),
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _perfil_routing_module__WEBPACK_IMPORTED_MODULE_0__.PerfilPageRoutingModule,
        ],
        declarations: [
            src_app_componentes_profissional_header_profissional_header_component__WEBPACK_IMPORTED_MODULE_2__.ProfissionalHeaderComponent,
            src_app_componentes_profissional_footer_profissional_footer_component__WEBPACK_IMPORTED_MODULE_3__.ProfissionalFooterComponent,
            _perfil_page__WEBPACK_IMPORTED_MODULE_1__.PerfilPage,
        ],
    })
], PerfilPageModule);



/***/ }),

/***/ 8412:
/*!************************************************************!*\
  !*** ./src/app/paginas/profissional/perfil/perfil.page.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PerfilPage": () => (/* binding */ PerfilPage)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _perfil_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./perfil.page.html?ngResource */ 3723);
/* harmony import */ var _perfil_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./perfil.page.scss?ngResource */ 299);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_services_profissional_profissionalService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/profissional/profissionalService */ 1668);
/* harmony import */ var src_app_services_erroService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/erroService */ 8592);









let PerfilPage = class PerfilPage {
  constructor(http, route, router) {
    this.http = http;
    this.router = router;
    this.profissional = {};
    route.params.subscribe(val => {
      this.carrega();
    });
  }

  carrega() {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.mensagem = '';
      _this.csenha = '';
      _this.profissional = src_app_services_profissional_profissionalService__WEBPACK_IMPORTED_MODULE_3__.ProfissionalServico.getSessao();
    })();
  }

  ngOnInit() {}

  atualizar() {
    var _this2 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (!_this2.profissional.nome || _this2.profissional.nome === '') {
        _this2.mensagem = 'Nome obrigatório';
        return;
      }

      if (!_this2.profissional.fone || _this2.profissional.fone === '') {
        _this2.mensagem = 'Whatsapp é obrigatório';
        return;
      }

      if (_this2.profissional.senha) {
        if (_this2.profissional.senha !== _this2.csenha) {
          _this2.mensagem = 'Senha não está igual a confirmação de senha';
          return;
        }
      }

      try {
        const profissionalLogado = yield new src_app_services_profissional_profissionalService__WEBPACK_IMPORTED_MODULE_3__.ProfissionalServico(_this2.http).atualizar(_this2.profissional);
        src_app_services_profissional_profissionalService__WEBPACK_IMPORTED_MODULE_3__.ProfissionalServico.setSessao(profissionalLogado);

        _this2.voltarConta();
      } catch (e) {
        _this2.mensagem = src_app_services_erroService__WEBPACK_IMPORTED_MODULE_4__.ErroServico.mensagemErro(e);
      }
    })();
  }

  voltarConta() {
    this.router.navigateByUrl('/profissional/conta');
  }

};

PerfilPage.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
}];

PerfilPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-perfil',
  template: _perfil_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_perfil_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], PerfilPage);


/***/ }),

/***/ 6521:
/*!*****************************************!*\
  !*** ./src/app/services/loadService.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoadService": () => (/* binding */ LoadService)
/* harmony export */ });
class LoadService {
    static show() {
        document.getElementById("loading").style.display = "block";
    }
    static hide() {
        document.getElementById("loading").style.display = "none";
    }
}


/***/ }),

/***/ 299:
/*!*************************************************************************!*\
  !*** ./src/app/paginas/profissional/perfil/perfil.page.scss?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = ".clique {\n  color: #000;\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBlcmZpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0VBQ0EsaUJBQUE7QUFDSiIsImZpbGUiOiJwZXJmaWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNsaXF1ZXtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbn0iXX0= */";

/***/ }),

/***/ 3723:
/*!*************************************************************************!*\
  !*** ./src/app/paginas/profissional/perfil/perfil.page.html?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "<app-profissional-header></app-profissional-header>\n\n<ion-content>\n  <section class=\"main-area text-center\">\n    <div class=\"titulo-local\">\n      <div class=\"texto\">Dados Pessoais</div>\n      <div class=\"icon-marca\">\n        <img src=\"assets/images/marca/elemento-branco.png\" alt=\"elemento\">\n      </div>\n    </div>\n\n    <div class=\"dados-pessoais\">\n      <form>\n        <div class=\"group\">\n          <div class=\"form-group\">\n            <input type=\"text\" [(ngModel)]=\"profissional.nome\" class=\"box\" id=\"nome\" name=\"nome\" placeholder=\"Digite seu nome\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/name.png\" alt=\"name\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input type=\"text\" [(ngModel)]=\"profissional.fone\" class=\"box\"\n              mask=\"(00) 00000-0000\" id=\"fone\" name=\"fone\" placeholder=\"Digite seu telefone\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/celular.png\" alt=\"celular\">\n            </div>\n          </div>\n        </div>\n\n\n        <div class=\"group\">\n          <div class=\"form-group\">\n            <input type=\"password\" [(ngModel)]=\"profissional.senha\" class=\"box\" id=\"senha\" name=\"senha\" placeholder=\"Senha\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/key.png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input type=\"password\" [(ngModel)]=\"csenha\" class=\"box\" id=\"csenha\" name=\"csenha\"\n              placeholder=\"Confirmação de Senha\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/key.png\" alt=\"\">\n            </div>\n          </div>\n        </div>\n\n        <div class=\"text-center actions\">\n          <button class=\"btn btn-warning\" style=\"padding: 5px 7px; width: 100%;margin-bottom: 5px;\" (click)=\"atualizar()\">Salvar</button>\n          <button class=\"btn btn-primary\" (click)=\"voltarConta()\">Voltar</button>\n        </div>\n\n        <div class=\"informacoes-adicionais\">\n          <div>\n            Para entrar em contato com o administrador e trocar o email\n            <a href=\"https://api.whatsapp.com/send?phone=5573991522828&text=Ol%C3%A1%20quero%20trocar%20meu%20e-mail%20no%20site%20Cli28\"\n              target=\"_blank\" class=\"clique\">Clique aqui</a>\n          </div>\n        </div>\n\n        <div id=\"mensagemErro\" *ngIf=\"mensagem\" [innerHTML]=\"mensagem\" class=\"alert alert-warning\"\n          style=\"margin-top: 20px;\"></div>\n      </form>\n    </div>\n  </section>\n</ion-content>\n\n<app-profissional-footer></app-profissional-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_paginas_profissional_perfil_perfil_module_ts-src_app_services_loadService_ts.js.map