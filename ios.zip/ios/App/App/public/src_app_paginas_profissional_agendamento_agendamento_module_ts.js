"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_paginas_profissional_agendamento_agendamento_module_ts"],{

/***/ 5996:
/*!********************************************************************************!*\
  !*** ./src/app/paginas/profissional/agendamento/agendamento-routing.module.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgendamentoPageRoutingModule": () => (/* binding */ AgendamentoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _agendamento_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./agendamento.page */ 435);




const routes = [
    {
        path: '',
        component: _agendamento_page__WEBPACK_IMPORTED_MODULE_0__.AgendamentoPage,
    }
];
let AgendamentoPageRoutingModule = class AgendamentoPageRoutingModule {
};
AgendamentoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], AgendamentoPageRoutingModule);



/***/ }),

/***/ 3710:
/*!************************************************************************!*\
  !*** ./src/app/paginas/profissional/agendamento/agendamento.module.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgendamentoPageModule": () => (/* binding */ AgendamentoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _agendamento_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./agendamento-routing.module */ 5996);
/* harmony import */ var src_app_componentes_profissional_header_profissional_header_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/componentes/profissional-header/profissional-header.component */ 8789);
/* harmony import */ var src_app_componentes_profissional_footer_profissional_footer_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/componentes/profissional-footer/profissional-footer.component */ 5043);
/* harmony import */ var _agendamento_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./agendamento.page */ 435);









let AgendamentoPageModule = class AgendamentoPageModule {
};
AgendamentoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _agendamento_routing_module__WEBPACK_IMPORTED_MODULE_0__.AgendamentoPageRoutingModule,
        ],
        declarations: [
            src_app_componentes_profissional_header_profissional_header_component__WEBPACK_IMPORTED_MODULE_1__.ProfissionalHeaderComponent,
            src_app_componentes_profissional_footer_profissional_footer_component__WEBPACK_IMPORTED_MODULE_2__.ProfissionalFooterComponent,
            _agendamento_page__WEBPACK_IMPORTED_MODULE_3__.AgendamentoPage,
        ],
    })
], AgendamentoPageModule);



/***/ }),

/***/ 435:
/*!**********************************************************************!*\
  !*** ./src/app/paginas/profissional/agendamento/agendamento.page.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgendamentoPage": () => (/* binding */ AgendamentoPage)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _agendamento_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./agendamento.page.html?ngResource */ 4323);
/* harmony import */ var _agendamento_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./agendamento.page.scss?ngResource */ 1040);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_services_profissional_clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/profissional/clinicaProcedimentoService */ 5926);
/* harmony import */ var src_app_services_profissional_atendimentoStatus__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/profissional/atendimentoStatus */ 6879);
/* harmony import */ var src_app_services_profissional_profissionalService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/profissional/profissionalService */ 1668);
/* harmony import */ var src_app_services_profissional_profissionalCidadeService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/profissional/profissionalCidadeService */ 407);











let AgendamentoPage = class AgendamentoPage {
  constructor(http, router, routerParams) {
    this.http = http;
    this.router = router;
    this.routerParams = routerParams;
    this.dependente = {};
    this.status = '';
    this.local = '';
  }

  ngOnInit() {
    this.carrega();
    this.atendimentosStatus();
  }

  carrega() {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.profissionais = yield new src_app_services_profissional_profissionalService__WEBPACK_IMPORTED_MODULE_5__.ProfissionalServico(_this.http).todos();
      _this.profissional_cidades = yield new src_app_services_profissional_profissionalCidadeService__WEBPACK_IMPORTED_MODULE_6__.ProfissionalCidadeServico(_this.http).locaisAtendimentos();
      _this.itens = yield new src_app_services_profissional_clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_3__.ClinicaProcedimentoService(_this.http).minhaAgenda();
    })();
  }

  atendimentosStatus() {
    var _this2 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.atendimentoStatus = yield new src_app_services_profissional_atendimentoStatus__WEBPACK_IMPORTED_MODULE_4__.AtendimentoStatusService(_this2.http).todos();
    })();
  }

  buscaAgenda() {
    var _this3 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const parametros = {
        data_inicial: _this3.data_inicial,
        data_final: _this3.data_final,
        status: _this3.status,
        profissional_id: _this3.dependente.id,
        local: _this3.local
      };
      _this3.itens = yield new src_app_services_profissional_clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_3__.ClinicaProcedimentoService(_this3.http).minhaAgenda(parametros);
    })();
  }

  saveStatus(item) {
    var _this4 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (confirm('Deseja atualizar o Status dessa consulta?')) {
        if (item.atendimento_status === 0) {
          return;
        }

        const clinicaProcedimento = {};
        clinicaProcedimento.id = item.clinica_procedimentos_id;
        clinicaProcedimento.atendimento_status = item.atendimento_status;
        clinicaProcedimento.atendimento_data = new Date();
        yield new src_app_services_profissional_clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_3__.ClinicaProcedimentoService(_this4.http).atualizar(clinicaProcedimento);
      }

      _this4.buscaAgenda();
    })();
  }

  limparFiltros() {
    this.data_inicial = null;
    this.data_final = null;
    this.status = '';
    this.local = '';
    this.dependente.id = null;
    this.buscaAgenda();
  }

  abrirPaciente(paciente_id) {
    this.router.navigateByUrl(`/profissional/pacientes/${paciente_id}`);
  }

};

AgendamentoPage.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClient
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute
}];

AgendamentoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-agendamento',
  template: _agendamento_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_agendamento_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], AgendamentoPage);


/***/ }),

/***/ 6521:
/*!*****************************************!*\
  !*** ./src/app/services/loadService.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoadService": () => (/* binding */ LoadService)
/* harmony export */ });
class LoadService {
    static show() {
        document.getElementById("loading").style.display = "block";
    }
    static hide() {
        document.getElementById("loading").style.display = "none";
    }
}


/***/ }),

/***/ 6879:
/*!************************************************************!*\
  !*** ./src/app/services/profissional/atendimentoStatus.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AtendimentoStatusService": () => (/* binding */ AtendimentoStatusService)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ 2340);
/* harmony import */ var src_app_services_loadService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/loadService */ 6521);
/* harmony import */ var _profissionalService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./profissionalService */ 1668);





class AtendimentoStatusService {
  constructor(http) {
    this.http = http;
  }

  todos() {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      src_app_services_loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/profissional/atendimento_status.json`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_profissionalService__WEBPACK_IMPORTED_MODULE_3__.ProfissionalServico.token()}`
          })
        }).toPromise();
        src_app_services_loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        src_app_services_loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

}

/***/ }),

/***/ 5926:
/*!*********************************************************************!*\
  !*** ./src/app/services/profissional/clinicaProcedimentoService.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClinicaProcedimentoService": () => (/* binding */ ClinicaProcedimentoService)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ 2340);
/* harmony import */ var src_app_services_loadService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/loadService */ 6521);
/* harmony import */ var _profissionalService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./profissionalService */ 1668);





class ClinicaProcedimentoService {
  constructor(http) {
    this.http = http;
  }

  minhaAgenda(parametros = {}) {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      src_app_services_loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/profissional/clinica_procedimentos/minha_agenda.json?busca=${JSON.stringify(parametros)}`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_profissionalService__WEBPACK_IMPORTED_MODULE_3__.ProfissionalServico.token()}`
          })
        }).toPromise();
        src_app_services_loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        src_app_services_loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  atualizar(clinicaProcedimento) {
    var _this2 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      src_app_services_loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this2.http.put(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/profissional/clinica_procedimentos/${clinicaProcedimento.id}.json`, {
          clinica_procedimento: clinicaProcedimento
        }, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_profissionalService__WEBPACK_IMPORTED_MODULE_3__.ProfissionalServico.token()}`
          })
        }).toPromise();
        src_app_services_loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        src_app_services_loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

}

/***/ }),

/***/ 1040:
/*!***********************************************************************************!*\
  !*** ./src/app/paginas/profissional/agendamento/agendamento.page.scss?ngResource ***!
  \***********************************************************************************/
/***/ ((module) => {

module.exports = "#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFnZW5kYW1lbnRvLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0VBRUEsa0JBQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLFFBQUE7RUFDQSwyQkFBQTtBQUFGOztBQUdBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBQUY7O0FBR0E7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFFQSxjQUFBO0VBRUEsU0FBQTtBQUZGOztBQUtBO0VBQ0UscUJBQUE7QUFGRiIsImZpbGUiOiJhZ2VuZGFtZW50by5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjY29udGFpbmVyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMDtcbiAgcmlnaHQ6IDA7XG4gIHRvcDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG59XG5cbiNjb250YWluZXIgc3Ryb25nIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBsaW5lLWhlaWdodDogMjZweDtcbn1cblxuI2NvbnRhaW5lciBwIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBsaW5lLWhlaWdodDogMjJweDtcblxuICBjb2xvcjogIzhjOGM4YztcblxuICBtYXJnaW46IDA7XG59XG5cbiNjb250YWluZXIgYSB7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbn0iXX0= */";

/***/ }),

/***/ 4323:
/*!***********************************************************************************!*\
  !*** ./src/app/paginas/profissional/agendamento/agendamento.page.html?ngResource ***!
  \***********************************************************************************/
/***/ ((module) => {

module.exports = "<app-profissional-header></app-profissional-header>\n\n<ion-content>\n  <section class=\"main-area text-center\">\n    <div class=\"titulo-local\">\n      <div class=\"texto\">Meus Agendamentos</div>\n      <div class=\"icon-marca\">\n        <img src=\"assets/images/marca/elemento-branco.png\" alt=\"elemento\">\n      </div>\n    </div>\n\n    <div id=\"filtros\">\n      <div class=\"filtros\">\n        <div *ngIf=\"!profissionais || profissionais.length > 1\">\n          <p>Profissional:</p>\n          <select [(ngModel)]=\"dependente.id\" class=\"select-area\">\n            <option value=\"\">Selecione</option>\n            <option *ngFor=\"let profissional of profissionais\" value=\"{{profissional.id}}\">\n              {{profissional.nome}}</option>\n          </select>\n        </div>\n\n        <div>\n          <br>\n          <p>Locais:</p>\n          <select [(ngModel)]=\"local\" class=\"select-area\">\n            <option value=\"\">Selecione</option>\n            <option *ngFor=\"let profissional_cidade of profissional_cidades\" value=\"{{profissional_cidade.atendimento_local}}\">\n              {{profissional_cidade.atendimento_local}}</option>\n          </select>\n        </div>\n\n        <div>\n          <br>\n          <p>Período:</p>\n          <input type=\"date\" [(ngModel)]=\"data_inicial\" >\n          <input type=\"date\" [(ngModel)]=\"data_final\">\n        </div>\n\n        <div>\n          <br>\n          <p>Status:</p>\n          <select [(ngModel)]=\"status\" class=\"select-area\">\n            <option value=\"\">Selecione</option>\n            <option *ngFor=\"let atendimentoStatu of atendimentoStatus\" value=\"{{atendimentoStatu.id}}\">\n              {{atendimentoStatu.status}}</option>\n          </select>\n        </div>\n\n        <div>\n          <br>\n          <button class=\"btn btn-primary\" style=\"margin-right: 3px;\" (click)=\"buscaAgenda()\">Buscar</button>\n          <button class=\"btn btn-warning\" (click)=\"limparFiltros()\">Limpar Filtros</button>\n        </div>\n      </div>\n    </div>\n\n    <div id=\"agendamento\">\n      <div *ngIf=\"!itens || itens.length === 0\" class=\"alert alert-warning\">Agendamentos não encontrado!</div>\n      <div class=\"agendamentos\" *ngIf=\"itens && itens.length > 0\">\n        <div *ngFor=\"let item of itens\">\n          <div class=\"paciente\">\n            <div (click)=\"abrirPaciente(item.paciente_id)\">\n              <span class=\"titulo\">PACIENTE</span>\n              <span>{{item.paciente_nome}}</span>\n            </div>\n          </div>\n\n          <div class=\"agendamento\">\n            <div class=\"conteudo\">\n              <div class=\"dados\">\n                <div class=\"nome\">{{(item.profissional.length > 25)? (item.profissional | slice:0:25)+'.':(item.profissional)}}</div>\n                <div class=\"crm\">{{item.vl_procedimento | currency : 'BRL'}}</div>\n              </div>\n              <div class=\"dados\" style=\"width: 93%;\">\n                <div class=\"nome\" style=\"width: 72%;\">{{item.consultorio}}</div>\n                <div class=\"crm\" style=\"width: 31%;\">{{item.cd_agendamento}}</div>\n              </div>\n              <div class=\"dados\">\n                <div class=\"nome\">{{item.data}}</div>\n                <div class=\"crm\">{{item.dia}}</div>\n                <div class=\"item\">{{item.inicio}}</div>\n                <div class=\"status\">\n                  <div *ngIf=\"item.atendimento_status === 1\">\n                    <select [(ngModel)]=\"item.atendimento_status\" class=\"select-area\">\n                      <option value=\"1\">Atendido</option>\n                    </select>\n                  </div>\n                  <div *ngIf=\"item.atendimento_status !== 1\">\n                    <select [(ngModel)]=\"item.atendimento_status\" (change)=\"saveStatus(item)\" class=\"select-area\">\n                      <option value=\"0\">[Selecione Status]</option>\n                      <option *ngFor=\"let atendimentoStatu of atendimentoStatus\" value=\"{{atendimentoStatu.id}}\">\n                        {{atendimentoStatu.status}}</option>\n                    </select>\n                  </div>\n                </div>\n                <!-- <div class=\"status\">{{item.status | statusPedido}}</div> -->\n              </div>\n            </div>\n\n            <div class=\"icon-image\">\n              <img src=\"{{item.profissional_imagem}}\" alt=\"elemento\">\n            </div>\n          </div>\n        </div>\n        <br>\n      </div>\n    </div>\n\n  </section>\n</ion-content>\n\n<app-profissional-footer></app-profissional-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_paginas_profissional_agendamento_agendamento_module_ts.js.map