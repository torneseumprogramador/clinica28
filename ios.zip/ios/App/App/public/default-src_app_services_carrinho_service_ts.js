"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_services_carrinho_service_ts"],{

/***/ 2136:
/*!**********************************************!*\
  !*** ./src/app/services/carrinho.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CarrinhoService": () => (/* binding */ CarrinhoService)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./clinicaProcedimentoService */ 4731);
/* harmony import */ var _pacienteService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pacienteService */ 8839);






let CarrinhoService = class CarrinhoService {
  constructor(http) {
    this.http = http;
    this.quantidade = 0;
  }

  carregaQuantidade() {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let paciente = _pacienteService__WEBPACK_IMPORTED_MODULE_2__.PacienteServico.getSessao();
      _this.quantidade = yield new _clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_1__.ClinicaProcedimentoService(_this.http).quantidade(paciente.id);
    })();
  }

};

CarrinhoService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient
}];

CarrinhoService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
  providedIn: 'root'
})], CarrinhoService);


/***/ }),

/***/ 4731:
/*!********************************************************!*\
  !*** ./src/app/services/clinicaProcedimentoService.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClinicaProcedimentoService": () => (/* binding */ ClinicaProcedimentoService)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ 2340);
/* harmony import */ var _loadService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./loadService */ 6521);
/* harmony import */ var _pacienteService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pacienteService */ 8839);





class ClinicaProcedimentoService {
  constructor(http) {
    this.http = http;
  }

  salvar(clinicaProcedimentoSalvar) {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const rota = clinicaProcedimentoSalvar.procedimento_id && clinicaProcedimentoSalvar.procedimento_id > 0 ? 'carrinho' : 'carrinho_procedimentos';
        const data = yield _this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/${rota}.json`, clinicaProcedimentoSalvar, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  quantidade(pacienteId) {
    var _this2 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this2.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/quantidade-carrinho.json?paciente_id=${pacienteId}`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  carrinho(pacienteId) {
    var _this3 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this3.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/carrinho.json?paciente_id=${pacienteId}`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  pedidos(pacienteId) {
    var _this4 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        const data = yield _this4.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pedidos.json?paciente_id=${pacienteId}`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        return data;
      } catch (e) {
        throw e;
      }
    })();
  }

  pedido(pacienteId, pedidoId) {
    var _this5 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        const data = yield _this5.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pedido/${pedidoId}.json?paciente_id=${pacienteId}`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        return data;
      } catch (e) {
        throw e;
      }
    })();
  }

  enviarWhatsApp(pacienteId, pedidoId) {
    var _this6 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        const data = yield _this6.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pedido/${pedidoId}/enviar_whatsapp.json`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        return data;
      } catch (e) {
        throw e;
      }
    })();
  }

  pedidoCancelado(pacienteId, pedidoId) {
    var _this7 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        yield _this7.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pedido/${pedidoId}/cancelar.json?paciente_id=${pacienteId}`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  pedidoAberto(pacienteId) {
    var _this8 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this8.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pedido-aberto.json?paciente_id=${pacienteId}`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  itensPedido(pacienteId, pedidoId) {
    var _this9 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this9.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pedido/${pedidoId}/itens.json?paciente_id=${pacienteId}`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  minhaAgenda(pacienteId) {
    var _this10 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this10.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/minha-agenda.json?paciente_id=${pacienteId}`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  excluirItemCarrinho(pacienteId, clinica_procedimentos_id) {
    var _this11 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this11.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/excluir_item_carrinho.json`, {
          paciente_id: pacienteId,
          clinica_procedimentos_id
        }, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  fecharCarrinho(pacienteId, token, parcelas) {
    var _this12 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this12.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/fechar_carrinho.json`, {
          paciente_id: pacienteId,
          token,
          parcelas
        }, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  buscarPix(pacienteId) {
    var _this13 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this13.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/fechar_carrinho.json`, {
          paciente_id: pacienteId,
          method: 'pix'
        }, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

}

/***/ }),

/***/ 6521:
/*!*****************************************!*\
  !*** ./src/app/services/loadService.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoadService": () => (/* binding */ LoadService)
/* harmony export */ });
class LoadService {
    static show() {
        document.getElementById("loading").style.display = "block";
    }
    static hide() {
        document.getElementById("loading").style.display = "none";
    }
}


/***/ }),

/***/ 8839:
/*!*********************************************!*\
  !*** ./src/app/services/pacienteService.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PacienteServico": () => (/* binding */ PacienteServico)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ 2340);
/* harmony import */ var _loadService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./loadService */ 6521);




class PacienteServico {
  constructor(http) {
    this.http = http;
  }

  porCPFNaoLogado(cpf) {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pacientes/nao-logado.json?cpf=${cpf}`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders({
            authorization: `Bearer ${PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  novaSenha(paciente) {
    var _this2 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        yield _this2.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pacientes/${paciente.id}/nova-senha.json`, paciente).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  porCPF(cpf) {
    var _this3 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this3.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pacientes.json?cpf=${cpf}`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders({
            authorization: `Bearer ${PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  atendimento(paciente_id) {
    var _this4 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this4.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pacientes/${paciente_id}/atendimentos.json`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders({
            authorization: `Bearer ${PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  orcamentos(paciente_id) {
    var _this5 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this5.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pacientes/${paciente_id}/orcamentos.json`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders({
            authorization: `Bearer ${PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  updateAtendimento(atendimento) {
    var _this6 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        yield _this6.http.put(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pacientes/${atendimento.paciente_id}/atendimentos/${atendimento.id}/update.json`, atendimento, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders({
            authorization: `Bearer ${PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  cadastrarEmailSenha(paciente) {
    var _this7 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this7.http.put(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pacientes/${paciente.id}/nao-logado.json`, {
          paciente
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  salvarNaoLogado(paciente) {
    var _this8 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this8.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pacientes/nao-logado.json`, {
          paciente
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  salvar(paciente) {
    var _this9 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (paciente.id && paciente.id > 0) {
        return _this9.atualizar(paciente);
      }

      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this9.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pacientes.json`, {
          paciente
        }, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders({
            authorization: `Bearer ${PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  atualizar(paciente) {
    var _this10 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this10.http.put(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pacientes/${paciente.id}.json`, {
          paciente
        }, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders({
            authorization: `Bearer ${PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  inativar(paciente) {
    var _this11 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this11.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pacientes/${paciente.id}/inativar.json`, {}, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders({
            authorization: `Bearer ${PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  login(paciente) {
    var _this12 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this12.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/pacientes/login.json`, paciente, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders({
            authorization: `Bearer ${PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  static setSessao(paciente) {
    localStorage.setItem('paciente', JSON.stringify(paciente));
  }

  static logado() {
    return this.getSessao() != null && this.getSessao() != undefined;
  }

  static token() {
    if (!this.logado()) {
      return null;
    }

    return this.getSessao().token;
  }

  static getSessao() {
    try {
      return JSON.parse(localStorage.getItem('paciente'));
    } catch (e) {
      return null;
    }
  }

  static removeSessao() {
    localStorage.removeItem('paciente');
  }

  static validaCPF(strCpf) {
    let soma;
    let resto;
    soma = 0;
    strCpf = strCpf.toString().replace(/\-|\./g, '');

    if (strCpf == '00000000000') {
      return false;
    }

    if (strCpf == '11111111111') {
      return false;
    }

    if (strCpf == '22222222222') {
      return false;
    }

    if (strCpf == '33333333333') {
      return false;
    }

    if (strCpf == '44444444444') {
      return false;
    }

    if (strCpf == '55555555555') {
      return false;
    }

    if (strCpf == '66666666666') {
      return false;
    }

    if (strCpf == '77777777777') {
      return false;
    }

    if (strCpf == '88888888888') {
      return false;
    }

    if (strCpf == '99999999999') {
      return false;
    }

    for (let i = 1; i <= 9; i++) {
      soma = soma + parseInt(strCpf.substring(i - 1, i)) * (11 - i);
    }

    resto = soma % 11;

    if (resto == 10 || resto == 11 || resto < 2) {
      resto = 0;
    } else {
      resto = 11 - resto;
    }

    if (resto != parseInt(strCpf.substring(9, 10))) {
      return false;
    }

    soma = 0;

    for (let i = 1; i <= 10; i++) {
      soma = soma + parseInt(strCpf.substring(i - 1, i)) * (12 - i);
    }

    resto = soma % 11;

    if (resto == 10 || resto == 11 || resto < 2) {
      resto = 0;
    } else {
      resto = 11 - resto;
    }

    if (resto != parseInt(strCpf.substring(10, 11))) {
      return false;
    }

    return true;
  }

}

/***/ })

}]);
//# sourceMappingURL=default-src_app_services_carrinho_service_ts.js.map