"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_paginas_profissional_home_home_module_ts-src_app_services_modalService_ts"],{

/***/ 8752:
/*!************************************************************!*\
  !*** ./src/app/componentes/carrinho/carrinho.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CarrinhoComponent": () => (/* binding */ CarrinhoComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _carrinho_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./carrinho.component.html?ngResource */ 246);
/* harmony import */ var _carrinho_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./carrinho.component.scss?ngResource */ 6167);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_helpers_servico__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/helpers/servico */ 9000);
/* harmony import */ var src_app_services_carrinho_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/carrinho.service */ 2136);
/* harmony import */ var src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/pacienteService */ 8839);








let CarrinhoComponent = class CarrinhoComponent {
    constructor(router, route, carrinhoService) {
        this.router = router;
        this.carrinhoService = carrinhoService;
        route.params.subscribe(val => {
            if (!src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_4__.PacienteServico.logado()) {
                this.router.navigateByUrl('/login');
                return;
            }
            clearInterval(src_app_helpers_servico__WEBPACK_IMPORTED_MODULE_2__.Servico.pedidoInterval);
            clearInterval(src_app_helpers_servico__WEBPACK_IMPORTED_MODULE_2__.Servico.startTimerInterval);
            this.carrinhoService.carregaQuantidade();
        });
    }
    ngOnInit() { }
};
CarrinhoComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute },
    { type: src_app_services_carrinho_service__WEBPACK_IMPORTED_MODULE_3__.CarrinhoService }
];
CarrinhoComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-carrinho',
        template: _carrinho_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_carrinho_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CarrinhoComponent);



/***/ }),

/***/ 9000:
/*!************************************!*\
  !*** ./src/app/helpers/servico.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Servico": () => (/* binding */ Servico)
/* harmony export */ });
class Servico {
}
Servico.pedidoInterval = null;
Servico.startTimerInterval = null;


/***/ }),

/***/ 86:
/*!******************************************************************!*\
  !*** ./src/app/paginas/profissional/home/home-routing.module.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 7202);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], HomePageRoutingModule);



/***/ }),

/***/ 2756:
/*!**********************************************************!*\
  !*** ./src/app/paginas/profissional/home/home.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home-routing.module */ 86);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page */ 7202);
/* harmony import */ var src_app_componentes_profissional_header_profissional_header_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/componentes/profissional-header/profissional-header.component */ 8789);
/* harmony import */ var src_app_componentes_profissional_footer_profissional_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/componentes/profissional-footer/profissional-footer.component */ 5043);
/* harmony import */ var src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/componentes/carrinho/carrinho.component */ 8752);
/* harmony import */ var src_app_componentes_versao_versao_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/componentes/versao/versao.component */ 8542);
/* harmony import */ var src_app_componentes_popup_popup_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/componentes/popup/popup.component */ 7513);












let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.NgModule)({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonicModule, _home_routing_module__WEBPACK_IMPORTED_MODULE_0__.HomePageRoutingModule],
        declarations: [
            _home_page__WEBPACK_IMPORTED_MODULE_1__.HomePage,
            src_app_componentes_profissional_header_profissional_header_component__WEBPACK_IMPORTED_MODULE_2__.ProfissionalHeaderComponent,
            src_app_componentes_profissional_footer_profissional_footer_component__WEBPACK_IMPORTED_MODULE_3__.ProfissionalFooterComponent,
            src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_4__.CarrinhoComponent,
            src_app_componentes_versao_versao_component__WEBPACK_IMPORTED_MODULE_5__.VersaoComponent,
            src_app_componentes_popup_popup_component__WEBPACK_IMPORTED_MODULE_6__.PopupComponent,
        ],
    })
], HomePageModule);



/***/ }),

/***/ 7202:
/*!********************************************************!*\
  !*** ./src/app/paginas/profissional/home/home.page.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.html?ngResource */ 6043);
/* harmony import */ var _home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home.page.scss?ngResource */ 9905);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_helpers_servico__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/helpers/servico */ 9000);
/* harmony import */ var src_app_services_profissional_imagemService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/profissional/imagemService */ 1653);
/* harmony import */ var src_app_services_profissional_profissionalService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/profissional/profissionalService */ 1668);










let HomePage = class HomePage {
  constructor(http, router) {
    this.http = http;
    this.router = router;
  }

  ngOnInit() {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (!src_app_services_profissional_profissionalService__WEBPACK_IMPORTED_MODULE_5__.ProfissionalServico.logado()) {
        _this.router.navigateByUrl('/profissional/login');
      }

      clearInterval(src_app_helpers_servico__WEBPACK_IMPORTED_MODULE_3__.Servico.pedidoInterval);
      _this.profissional = src_app_services_profissional_profissionalService__WEBPACK_IMPORTED_MODULE_5__.ProfissionalServico.getSessao();
      _this.imagens = yield new src_app_services_profissional_imagemService__WEBPACK_IMPORTED_MODULE_4__.ImagemServico(_this.http).todos();
    })();
  }

};

HomePage.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router
}];

HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-home',
  template: _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], HomePage);


/***/ }),

/***/ 4704:
/*!******************************************!*\
  !*** ./src/app/services/modalService.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalService": () => (/* binding */ ModalService)
/* harmony export */ });
class ModalService {
    static show(titulo, texto, textoBotao = 'Voltar para o site', carrinho = true, forceCloseModalShow = false, callback) {
        //@ts-ignore
        custonModal.open(titulo, texto, textoBotao, carrinho, forceCloseModalShow);
        //@ts-ignore
        custonModal.callback = callback;
    }
    static popup(image, numPopup) {
        //@ts-ignore
        custonPopup.open(image, numPopup);
    }
}


/***/ }),

/***/ 1653:
/*!********************************************************!*\
  !*** ./src/app/services/profissional/imagemService.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ImagemServico": () => (/* binding */ ImagemServico)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ 2340);
/* harmony import */ var _loadService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../loadService */ 6521);
/* harmony import */ var _profissionalService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./profissionalService */ 1668);





class ImagemServico {
  constructor(http) {
    this.http = http;
  }

  todos() {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/profissional/imagens.json`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_profissionalService__WEBPACK_IMPORTED_MODULE_3__.ProfissionalServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

}

/***/ }),

/***/ 6167:
/*!*************************************************************************!*\
  !*** ./src/app/componentes/carrinho/carrinho.component.scss?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "a {\n  position: absolute;\n  z-index: 999999;\n  color: #fff;\n  margin-top: -90px;\n  margin-left: 14px;\n  font-size: 18px;\n  text-decoration: none;\n  display: inline-block;\n  background: #f00;\n  width: 40px;\n  border-radius: 30px;\n  height: 40px;\n  padding-top: 6px;\n  text-align: center;\n}\n\n@media only screen and (max-width: 600px) {\n  a {\n    margin-top: -70px;\n    margin-left: 64px;\n    font-size: 16px;\n    background: #f00;\n    width: 30px;\n    border-radius: 30px;\n    height: 30px;\n    padding-top: 2px;\n  }\n}\n\n@media only screen and (max-width: 420px) {\n  a {\n    margin-top: -62px;\n    margin-left: 9px;\n    width: 25px;\n    height: 27px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhcnJpbmhvLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EscUJBQUE7RUFDQSxxQkFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUFDSjs7QUFFQTtFQUNJO0lBQ0ksaUJBQUE7SUFDQSxpQkFBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLFdBQUE7SUFDQSxtQkFBQTtJQUNBLFlBQUE7SUFDQSxnQkFBQTtFQUNOO0FBQ0Y7O0FBRUE7RUFDRTtJQUNFLGlCQUFBO0lBQ0EsZ0JBQUE7SUFDQSxXQUFBO0lBQ0EsWUFBQTtFQUFGO0FBQ0YiLCJmaWxlIjoiY2FycmluaG8uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJhe1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB6LWluZGV4OiA5OTk5OTk7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgbWFyZ2luLXRvcDogLTkwcHg7XG4gICAgbWFyZ2luLWxlZnQ6IDE0cHg7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgYmFja2dyb3VuZDogI2YwMDtcbiAgICB3aWR0aDogNDBweDtcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICAgIGhlaWdodDogNDBweDtcbiAgICBwYWRkaW5nLXRvcDogNnB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA2MDBweCkge1xuICAgIGF7XG4gICAgICAgIG1hcmdpbi10b3A6IC03MHB4O1xuICAgICAgICBtYXJnaW4tbGVmdDogNjRweDtcbiAgICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgICAgICBiYWNrZ3JvdW5kOiAjZjAwO1xuICAgICAgICB3aWR0aDogMzBweDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgICAgICAgaGVpZ2h0OiAzMHB4O1xuICAgICAgICBwYWRkaW5nLXRvcDogMnB4O1xuICAgIH1cbn1cblxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA0MjBweCkge1xuICBhe1xuICAgIG1hcmdpbi10b3A6IC02MnB4O1xuICAgIG1hcmdpbi1sZWZ0OiA5cHg7XG4gICAgd2lkdGg6IDI1cHg7XG4gICAgaGVpZ2h0OiAyN3B4O1xuICB9XG59XG4iXX0= */";

/***/ }),

/***/ 9905:
/*!*********************************************************************!*\
  !*** ./src/app/paginas/profissional/home/home.page.scss?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJob21lLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 246:
/*!*************************************************************************!*\
  !*** ./src/app/componentes/carrinho/carrinho.component.html?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "<a routerLink=\"/carrinho\"> {{carrinhoService.quantidade}}</a>\n";

/***/ }),

/***/ 6043:
/*!*********************************************************************!*\
  !*** ./src/app/paginas/profissional/home/home.page.html?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = "<app-profissional-header></app-profissional-header>\n\n<ion-content [fullscreen]=\"true\">\n  <section class=\"main-area text-center\">\n    <div class=\"slideshow\" *ngIf=\"imagens && imagens.length > 0\">\n      <!-- Slideshow container -->\n      <div class=\"slideshow-container\" style=\"margin-top: 50pt;\" >\n        <div class=\"mySlides fade\" *ngFor=\"let imagem of imagens\">\n          <a href=\"{{imagem.endereco}}\" target=\"_blank\">\n            <img src=\"{{imagem.arquivo}}\" style=\"width:100%\">\n          </a>\n        </div>\n      </div>\n\n      <br>\n      <!-- The dots/circles -->\n      <div style=\"text-align:center\" >\n        <span class=\"dot\" *ngFor=\"let imagem of imagens\"></span>\n      </div>\n    </div>\n\n    <div class=\"icon-chat text-end\">\n      <a href=\"https://api.whatsapp.com/send?phone=5573991522828&text=Ol%C3%A1!%20Sou%20usu%C3%A1rio%20do%20Aplicativo%20Clinica%2028%20e%20preciso%20de%20um%20suporte.\" target=\"_blank\">\n        <img id=\"TELAx20INICIAL_22\" src=\"assets/images/TELA-INICIAL_22.png\" alt=\"\">\n      </a>\n    </div>\n  </section>\n</ion-content>\n\n<app-profissional-footer></app-profissional-footer>\n<app-versao></app-versao>\n<app-popup></app-popup>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_paginas_profissional_home_home_module_ts-src_app_services_modalService_ts.js.map