"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_paginas_carrinho_carrinho_module_ts"],{

/***/ 202:
/*!********************************************************!*\
  !*** ./src/app/componentes/footer/footer.component.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FooterComponent": () => (/* binding */ FooterComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _footer_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./footer.component.html?ngResource */ 6793);
/* harmony import */ var _footer_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./footer.component.scss?ngResource */ 503);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 124);





let FooterComponent = class FooterComponent {
    constructor(router, route) {
        this.router = router;
    }
    ngOnInit() {
        this.rota = this.router.url;
    }
};
FooterComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.ActivatedRoute }
];
FooterComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-footer',
        template: _footer_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_footer_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], FooterComponent);



/***/ }),

/***/ 4944:
/*!********************************************************!*\
  !*** ./src/app/componentes/header/header.component.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderComponent": () => (/* binding */ HeaderComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _header_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header.component.html?ngResource */ 5933);
/* harmony import */ var _header_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./header.component.scss?ngResource */ 489);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/pacienteService */ 8839);
/* harmony import */ var src_app_services_screenService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/screenService */ 1499);







let HeaderComponent = class HeaderComponent {
    constructor(router, route) {
        this.router = router;
        route.params.subscribe(val => {
            if (!src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_2__.PacienteServico.logado()) {
                this.router.navigateByUrl('/login');
            }
            src_app_services_screenService__WEBPACK_IMPORTED_MODULE_3__.ScreenService.load();
            this.paciente = src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_2__.PacienteServico.getSessao();
        });
    }
    ngOnInit() {
        //@ts-ignore
        screen.angular = {
            self: this,
            redirect: (path) => {
                //@ts-ignore
                screen.angular.self.router.navigateByUrl(path);
                //@ts-ignore
                screen.sideBar.classList.remove('active');
            },
            pacienteClass: src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_2__.PacienteServico,
            sair: () => {
                //@ts-ignore
                screen.angular.pacienteClass.removeSessao();
                //@ts-ignore
                screen.angular.self.router.navigateByUrl('/login');
                //@ts-ignore
                screen.sideBar.classList.remove('active');
            }
        };
        this.rota = this.router.url;
    }
};
HeaderComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute }
];
HeaderComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-header',
        template: _header_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_header_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HeaderComponent);



/***/ }),

/***/ 7601:
/*!*************************************************************!*\
  !*** ./src/app/paginas/carrinho/carrinho-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CarrinhoPageRoutingModule": () => (/* binding */ CarrinhoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _carrinho_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./carrinho.page */ 7957);




const routes = [
    {
        path: '',
        component: _carrinho_page__WEBPACK_IMPORTED_MODULE_0__.CarrinhoPage
    }
];
let CarrinhoPageRoutingModule = class CarrinhoPageRoutingModule {
};
CarrinhoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CarrinhoPageRoutingModule);



/***/ }),

/***/ 3926:
/*!*****************************************************!*\
  !*** ./src/app/paginas/carrinho/carrinho.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CarrinhoPageModule": () => (/* binding */ CarrinhoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _carrinho_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./carrinho-routing.module */ 7601);
/* harmony import */ var _carrinho_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./carrinho.page */ 7957);
/* harmony import */ var src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/componentes/header/header.component */ 4944);
/* harmony import */ var src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/componentes/footer/footer.component */ 202);









let CarrinhoPageModule = class CarrinhoPageModule {
};
CarrinhoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _carrinho_routing_module__WEBPACK_IMPORTED_MODULE_0__.CarrinhoPageRoutingModule
        ],
        declarations: [
            src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_2__.HeaderComponent, src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterComponent, _carrinho_page__WEBPACK_IMPORTED_MODULE_1__.CarrinhoPage
        ]
    })
], CarrinhoPageModule);



/***/ }),

/***/ 7957:
/*!***************************************************!*\
  !*** ./src/app/paginas/carrinho/carrinho.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CarrinhoPage": () => (/* binding */ CarrinhoPage)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _carrinho_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./carrinho.page.html?ngResource */ 3889);
/* harmony import */ var _carrinho_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./carrinho.page.scss?ngResource */ 5513);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_services_carrinho_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/carrinho.service */ 2136);
/* harmony import */ var src_app_services_clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/clinicaProcedimentoService */ 4731);
/* harmony import */ var src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/pacienteService */ 8839);










let CarrinhoPage = class CarrinhoPage {
  constructor(http, route, router, carrinhoService) {
    var _this = this;

    this.http = http;
    this.router = router;
    this.carrinhoService = carrinhoService;
    route.params.subscribe( /*#__PURE__*/function () {
      var _ref = (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (val) {
        yield _this.carrega();
      });

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());
  }

  ngOnInit() {}

  carrega() {
    var _this2 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.carrinho = yield new src_app_services_clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_4__.ClinicaProcedimentoService(_this2.http).carrinho(src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_5__.PacienteServico.getSessao().id);
    })();
  }

  excluir(item) {
    var _this3 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (confirm('Confirma?')) {
        yield new src_app_services_clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_4__.ClinicaProcedimentoService(_this3.http).excluirItemCarrinho(src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_5__.PacienteServico.getSessao().id, item.clinica_procedimentos_id);

        _this3.carrinhoService.carregaQuantidade();

        _this3.carrega();
      }
    })();
  }

  valorTotal() {
    let valor = 0;

    for (const item of this.carrinho.itens) {
      valor = Number(valor) + Number(item.valor_final);
    }

    return valor;
  }

  valorSubotal() {
    let valor = 0;

    for (const item of this.carrinho.itens) {
      valor = Number(valor) + Number(item.vl_procedimento);
    }

    return valor;
  }

  valorDesconto() {
    let valor = 0;

    for (const item of this.carrinho.itens) {
      valor = Number(valor) + Number(item.desconto_valor);
    }

    return valor;
  }

  fecharCarrinho() {
    var _this4 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this4.router.navigateByUrl('/pagamento');
    })();
  }

};

CarrinhoPage.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router
}, {
  type: src_app_services_carrinho_service__WEBPACK_IMPORTED_MODULE_3__.CarrinhoService
}];

CarrinhoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-carrinho-page',
  template: _carrinho_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_carrinho_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], CarrinhoPage);


/***/ }),

/***/ 1499:
/*!*******************************************!*\
  !*** ./src/app/services/screenService.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ScreenService": () => (/* binding */ ScreenService)
/* harmony export */ });
/* harmony import */ var _pacienteService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pacienteService */ 8839);

class ScreenService {
    static load() {
        setTimeout(() => {
            //@ts-ignore
            screen.sideBar = document.querySelector('.side-bar');
            let paciente = _pacienteService__WEBPACK_IMPORTED_MODULE_0__.PacienteServico.getSessao();
            //@ts-ignore
            document.getElementById('pacienteNome').innerHTML = paciente.nome;
        }, 1000);
    }
}


/***/ }),

/***/ 503:
/*!*********************************************************************!*\
  !*** ./src/app/componentes/footer/footer.component.scss?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmb290ZXIuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 489:
/*!*********************************************************************!*\
  !*** ./src/app/componentes/header/header.component.scss?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = ".black {\n  color: #000 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHNCQUFBO0FBQ0oiLCJmaWxlIjoiaGVhZGVyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJsYWNre1xuICAgIGNvbG9yOiAjMDAwIWltcG9ydGFudDtcbn0iXX0= */";

/***/ }),

/***/ 5513:
/*!****************************************************************!*\
  !*** ./src/app/paginas/carrinho/carrinho.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjYXJyaW5oby5wYWdlLnNjc3MifQ== */";

/***/ }),

/***/ 6793:
/*!*********************************************************************!*\
  !*** ./src/app/componentes/footer/footer.component.html?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = "<ion-footer [translucent]=\"true\">\n  <footer>\n    <div class=\"marcacoes\">\n      <div class=\"marcacao\">\n        <div class=\"{{rota === '/home' ? 'ativo' : ''}}\"></div>\n      </div>\n      <div class=\"marcacao\">\n        <div class=\"{{rota === '/meus-agendamentos' ? 'ativo' : ''}}\"></div>\n      </div>\n      <div class=\"marcacao\">\n        <div class=\"{{rota === '/carrinho' ? 'ativo' : ''}}\"></div>\n      </div>\n      <div class=\"marcacao\">\n        <div class=\"{{rota === '/conta' ? 'ativo' : ''}}\"></div>\n      </div>\n    </div>\n\n    <div class=\"tabs-all\">\n      <div class=\"menus\">\n        <div class=\"tabs text-center\">\n          <a routerLink=\"/home\">\n            <img src=\"assets/images/svg/{{rota === '/home' ? 'coração-select' : 'coração'}}.svg\" alt=\"coração\" class=\"{{rota === '/home' ? 'ativo' : ''}}\">\n            <p class=\"{{rota === '/home' ? 'ativo' : ''}} text-center\">INÍCIO</p>\n          </a>\n        </div>\n        <div class=\"tabs text-center\">\n          <a routerLink=\"/meus-agendamentos\">\n            <img src=\"assets/images/svg/{{rota === '/meus-agendamentos' ? 'calendário-select' : 'calendário'}}.svg\" alt=\"calendário\" class=\"{{rota === '/meus-agendamentos' ? 'ativo' : ''}}\">\n            <p class=\"{{rota === '/meus-agendamentos' ? 'ativo' : ''}} text-center\">AGENDA</p>\n          </a>\n        </div>\n        <div class=\"tabs text-center\">\n          <a routerLink=\"/carrinho\">\n            <img src=\"assets/images/svg/{{rota === '/carrinho' ? 'carrinho_de_compras-select' : 'carrinho_de_compras'}}.svg\" alt=\"carrinho_de_compras\" class=\"{{rota === '/carrinho' ? 'ativo' : ''}}\">\n            <p class=\"{{rota === '/carrinho' ? 'ativo' : ''}} text-center\">CARRINHO</p>\n            <app-carrinho></app-carrinho>\n          </a>\n        </div>\n        <div class=\"tabs text-center\">\n          <a routerLink=\"/conta\">\n            <img src=\"assets/images/svg/{{rota === '/conta' ? 'avatar-select' : 'avatar'}}.svg\" alt=\"avatar\" class=\"{{rota === '/conta' ? 'ativo' : ''}}\">\n            <p class=\"{{rota === '/conta' ? 'ativo' : ''}} text-center\">CONTA</p>\n          </a>\n        </div>\n      </div>\n    </div>\n  </footer>\n</ion-footer>\n";

/***/ }),

/***/ 5933:
/*!*********************************************************************!*\
  !*** ./src/app/componentes/header/header.component.html?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\n  <div class=\"header-other\">\n    <img src=\"assets/images/wave/wave-onda.png\" alt=\"LOGIN_01\" class=\"img-responsive\" height=\"145px\">\n    <div class=\"step-actions\">\n      <div class=\"header-menus\" style=\"width: 100%;\" *ngIf=\"['/home', '/perfil'].includes(rota)\">\n        <div style=\"width: calc(100% - 44px);\">\n          <h1 style=\"width: calc(100% - 20px);\n          white-space: nowrap;\n          overflow: hidden;\n          color: #fff;\n          text-overflow: ellipsis;\">Olá, {{paciente.nome}}</h1>\n        </div>\n        <div class=\"icons\" style=\"width: 44px;\">\n          <a href=\"javascript:;\" style=\"color: white;font-size: 20px;margin-top: 29px;\" onclick=\"screen.angular.sair()\">Sair</a>\n        </div>\n      </div>\n\n      <div class=\"action\" *ngIf=\"!['/home', '/perfil'].includes(rota)\">\n        <a href=\"javascript:history.back()\">\n          <img src=\"assets/images/ADICIONADO-COM-SUCESSO-NO-CARRINHO_06.png\" alt=\"seta-para-a-esquerda\" class=\"seta\">\n        </a>\n      </div>\n      <div class=\"action text-center\" *ngIf=\"!['/home', '/perfil'].includes(rota)\">\n        <img src=\"assets/images/logo-28-branco.png\" alt=\"CARRINHO_03\" class=\"logo\">\n      </div>\n    </div>\n  </div>\n</ion-header>\n";

/***/ }),

/***/ 3889:
/*!****************************************************************!*\
  !*** ./src/app/paginas/carrinho/carrinho.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<app-header></app-header>\n\n<ion-content>\n  <section class=\"main-area text-center\">\n    <div class=\"titulo-local\">\n      <div class=\"texto\">Itens em seu Carrinho</div>\n      <div class=\"icon-marca\">\n        <img src=\"assets/images/marca/elemento-branco.png\" alt=\"elemento\">\n      </div>\n    </div>\n\n    <br><br>\n    <div *ngIf=\"!carrinho || carrinho.itens.length == 0\" class=\"alert alert-warning\">Nenhum item no carrinho!</div>\n    <div *ngIf=\"carrinho && carrinho.itens.length > 0\">\n      <div id=\"horarios\">\n        <div class=\"grupo-horarios\">\n          <div *ngIf=\"carrinho.itens && carrinho.itens.length > 0\">\n            <div class=\"cabecalho-horarios\">\n              <div class=\"options-carrinho\">Data /<br> Procedimento</div>\n              <div class=\"options-carrinho\">Paciente /<br> A partir das</div>\n              <div class=\"options-carrinho\">Unidade /<br> Valor</div>\n            </div>\n\n            <div *ngFor=\"let item of carrinho.itens\" style=\"border-bottom: 10px solid #fff;\">\n              <div class=\"horario\">\n                <div class=\"informacoes carrinho\">\n                  <div class=\"local\">\n                    {{item.data}}\n                  </div>\n                </div>\n\n                <div class=\"informacoes carrinho intercalacao\">\n                  <div class=\"local intercalacao\" style=\"font-size: 1rem;\">\n                    {{item.paciente}}\n                  </div>\n                </div>\n\n                <div class=\"informacoes carrinho\">\n                  <div *ngIf=\"item.cd_agendamento\" class=\"local\" style=\"font-size: 1rem;\">\n                    {{item.unidade}}\n                  </div>\n                  <div *ngIf=\"!item.cd_agendamento\" class=\"local\" style=\"font-size: 1rem;\">\n                    {{item.profissional}}\n                  </div>\n                </div>\n              </div>\n\n              <div class=\"horario\">\n                <div class=\"informacoes carrinho\">\n                  <div class=\"local\" style=\"font-size: 1rem;\">\n                    {{item.procedimento}}\n                  </div>\n                </div>\n\n                <div class=\"informacoes carrinho intercalacao\">\n                  <div class=\"local intercalacao\">\n                    {{item.inicio}}\n                  </div>\n                </div>\n\n                <div class=\"informacoes carrinho\" style=\"border-radius: 0 20px 20px 0;\">\n                  <div class=\"local\">\n                    {{item.vl_procedimento | currency : 'BRL'}}\n                  </div>\n                </div>\n              </div>\n\n              <div class=\"horario\">\n                <div style=\"flex: 19%\">\n                  <button class=\"btn btn-primary\" style=\"color: #ff7400;\"\n                  (click)=\"excluir(item)\">Excluir</button>\n                </div>\n              </div>\n\n            </div>\n          </div>\n        </div>\n      </div>\n\n      <br>\n\n      <div class=\"valor\">\n        <div class=\"valor-carrinho\">\n          <strong><span>Subtotal:</span> {{valorSubotal() | currency : 'BRL'}}</strong>\n        </div>\n\n        <div class=\"valor-carrinho\">\n          <strong><span>Desconto:</span> {{valorDesconto() | currency : 'BRL'}}</strong>\n        </div>\n\n        <div class=\"valor-carrinho\">\n          <strong><span>Total:</span> {{valorTotal() | currency : 'BRL'}}</strong>\n        </div>\n\n        <div class=\"actions text-end ir-pagamento\" (click)=\"fecharCarrinho()\">\n          <button type=\"button\" class=\"btn btn-warning\">Ir para Pagamento</button>\n          <div class=\"icon-flutuante\">\n            <img src=\"assets/images/icones/consulta.png\" alt=\"consulta\">\n          </div>\n        </div>\n      </div>\n      <br>\n    </div>\n  </section>\n</ion-content>\n\n<app-footer></app-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_paginas_carrinho_carrinho_module_ts.js.map