"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_paginas_procedimento-selecionado_procedimento-selecionado_module_ts"],{

/***/ 9134:
/*!*********************************************************************************************!*\
  !*** ./src/app/paginas/procedimento-selecionado/procedimento-selecionado-routing.module.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProcedimentoSelecionadoPageRoutingModule": () => (/* binding */ ProcedimentoSelecionadoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _procedimento_selecionado_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./procedimento-selecionado.page */ 676);




const routes = [
    {
        path: '',
        component: _procedimento_selecionado_page__WEBPACK_IMPORTED_MODULE_0__.ProcedimentoSelecionadoPage
    }
];
let ProcedimentoSelecionadoPageRoutingModule = class ProcedimentoSelecionadoPageRoutingModule {
};
ProcedimentoSelecionadoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProcedimentoSelecionadoPageRoutingModule);



/***/ }),

/***/ 2479:
/*!*************************************************************************************!*\
  !*** ./src/app/paginas/procedimento-selecionado/procedimento-selecionado.module.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProcedimentoSelecionadoPageModule": () => (/* binding */ ProcedimentoSelecionadoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _procedimento_selecionado_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./procedimento-selecionado-routing.module */ 9134);
/* harmony import */ var _procedimento_selecionado_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./procedimento-selecionado.page */ 676);
/* harmony import */ var src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/componentes/header/header.component */ 4944);
/* harmony import */ var src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/componentes/footer/footer.component */ 202);
/* harmony import */ var src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/componentes/carrinho/carrinho.component */ 8752);










let ProcedimentoSelecionadoPageModule = class ProcedimentoSelecionadoPageModule {
};
ProcedimentoSelecionadoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _procedimento_selecionado_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProcedimentoSelecionadoPageRoutingModule
        ],
        declarations: [_procedimento_selecionado_page__WEBPACK_IMPORTED_MODULE_1__.ProcedimentoSelecionadoPage,
            src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_2__.HeaderComponent, src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterComponent, src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_4__.CarrinhoComponent,
        ]
    })
], ProcedimentoSelecionadoPageModule);



/***/ }),

/***/ 676:
/*!***********************************************************************************!*\
  !*** ./src/app/paginas/procedimento-selecionado/procedimento-selecionado.page.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProcedimentoSelecionadoPage": () => (/* binding */ ProcedimentoSelecionadoPage)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _procedimento_selecionado_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./procedimento-selecionado.page.html?ngResource */ 8740);
/* harmony import */ var _procedimento_selecionado_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./procedimento-selecionado.page.scss?ngResource */ 4356);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_services_especialidadeService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/especialidadeService */ 2930);
/* harmony import */ var src_app_services_localConsultaService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/localConsultaService */ 2417);
/* harmony import */ var src_app_services_procedimentoService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/procedimentoService */ 3247);
/* harmony import */ var src_app_services_profissionaisHorariosDisponibilidadeServico__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/profissionaisHorariosDisponibilidadeServico */ 7103);
/* harmony import */ var src_app_services_profissionalService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/profissionalService */ 5268);












let ProcedimentoSelecionadoPage = class ProcedimentoSelecionadoPage {
  constructor(http, router, routerParams) {
    this.http = http;
    this.router = router;
    this.routerParams = routerParams;
    this.profissionais_horarios_disponibilidades = [];
    this.msg_profissionais_horarios_disponibilidades = '';
    this.local = '';
    this.atendimento_id = 1;
    this.cidade = '';
  }

  ngOnInit() {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const especialidade_id = _this.routerParams.snapshot.params.especialidade_id;
      const profissional_id = _this.routerParams.snapshot.params.profissional_id;
      const grupo_id = _this.routerParams.snapshot.params.grupo_id;
      const procedimento_id = _this.routerParams.snapshot.queryParams.procedimento_id || '';
      const dadosAtendimento = src_app_services_localConsultaService__WEBPACK_IMPORTED_MODULE_4__.LocalConsultaServico.getLocal();

      if (dadosAtendimento) {
        _this.atendimento_id = dadosAtendimento.atendimento_id;
        _this.cidade = dadosAtendimento.cidade;
      }

      _this.especialidade = yield new src_app_services_especialidadeService__WEBPACK_IMPORTED_MODULE_3__.EspecialidadeServico(_this.http).get(especialidade_id);
      _this.profissional = yield new src_app_services_profissionalService__WEBPACK_IMPORTED_MODULE_7__.ProfissionalServico(_this.http).getComAtendimento(profissional_id, _this.atendimento_id, _this.cidade);
      _this.procedimento = yield new src_app_services_procedimentoService__WEBPACK_IMPORTED_MODULE_5__.ProcedimentoServico(_this.http).getPorGrupoId(grupo_id, _this.profissional.id, procedimento_id, especialidade_id);
      _this.local = _this.profissional.atendimento_local || `${_this.procedimento?.procedimento} na 28 de Julho`;
      yield _this.carregaHorarios();
    })();
  }

  carregaHorarios() {
    var _this2 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this2.procedimento.id === undefined) {
        _this2.msg_profissionais_horarios_disponibilidades = 'Nenhum horário encontrado';
        return;
      }

      _this2.profissionais_horarios_disponibilidades = yield new src_app_services_profissionaisHorariosDisponibilidadeServico__WEBPACK_IMPORTED_MODULE_6__.ProfissionaisHorariosDisponibilidadeServico(_this2.http).porProcedimento(_this2.procedimento.id, _this2.profissional.id, _this2.atendimento_id);
      _this2.msg_profissionais_horarios_disponibilidades = _this2.profissionais_horarios_disponibilidades.length === 0 ? 'Nenhum horário encontrado' : '';
    })();
  }

  seleciona(profissionais_horarios_disponibilidade) {
    this.router.navigateByUrl(`/especialidade/${this.especialidade.id}/profissional/${this.profissional.id}/procedimento/${this.procedimento.id}/horario-selecionado/${profissionais_horarios_disponibilidade.id}`);
  }

};

ProcedimentoSelecionadoPage.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_8__.HttpClient
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.Router
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute
}];

ProcedimentoSelecionadoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
  selector: 'app-procedimento-selecionado-page',
  template: _procedimento_selecionado_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_procedimento_selecionado_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ProcedimentoSelecionadoPage);


/***/ }),

/***/ 4356:
/*!************************************************************************************************!*\
  !*** ./src/app/paginas/procedimento-selecionado/procedimento-selecionado.page.scss?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcm9jZWRpbWVudG8tc2VsZWNpb25hZG8ucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 8740:
/*!************************************************************************************************!*\
  !*** ./src/app/paginas/procedimento-selecionado/procedimento-selecionado.page.html?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header></app-header>\n\n<ion-content [fullscreen]=\"true\">\n  <section class=\"main-area text-center\">\n    <div class=\"titulo-local\">\n      <div class=\"texto\">{{especialidade?.especialidade}}</div>\n      <div class=\"icon-marca\">\n        <img src=\"assets/images/marca/elemento-branco.png\" alt=\"elemento\">\n      </div>\n    </div>\n\n    <div id=\"profissional\" *ngIf=\"profissional\">\n      <div class=\"profissionais\">\n        <div class=\"profissional\">\n          <div class=\"conteudo\">\n            <div class=\"local\">\n              <div class=\"fonte\">{{local}}</div>\n              <div class=\"agendar\" style=\"padding-left: 15px;\">\n                {{procedimento?.valor_procedimento | currency}}\n              </div>\n            </div>\n\n            <div class=\"dados\">\n              <div class=\"nome\">{{(profissional?.nome.length > 25)? (profissional?.nome | slice:0:25)+'.':(profissional?.nome)}}</div>\n              <div class=\"crm\">{{profissional?.crm}}</div>\n            </div>\n          </div>\n\n          <div class=\"icon-image\">\n            <img src=\"{{profissional?.imagem}}\" alt=\"elemento\">\n          </div>\n        </div>\n        <br>\n      </div>\n    </div>\n\n\n    <div id=\"horarios\">\n      <div *ngIf=\"msg_profissionais_horarios_disponibilidades\" class=\"alert alert-warning\">\n        {{msg_profissionais_horarios_disponibilidades}}\n      </div>\n      <div *ngIf=\"profissionais_horarios_disponibilidades && profissionais_horarios_disponibilidades.length > 0\">\n        <div class=\"disponibilidade\">\n          Disponibilidade de Horários\n        </div>\n        <div class=\"grupo-horarios\" >\n\n          <div class=\"cabecalho-horarios\">\n            <div class=\"options\">Data/Unidade</div>\n            <div class=\"options\">Dia/A partir das</div>\n          </div>\n\n          <div *ngFor=\"let profissionais_horarios_disponibilidade of profissionais_horarios_disponibilidades\" style=\"border-top: 10px solid #fff;\">\n            <div class=\"horario\">\n              <div class=\"informacoes\">\n                <div class=\"local\">\n                  {{profissionais_horarios_disponibilidade.data | date: 'dd/MM/YYYY'}}\n                </div>\n              </div>\n              <div class=\"informacoes intercalacao\">\n                <div class=\"local intercalacao\">\n                  {{profissionais_horarios_disponibilidade.dia}}\n                </div>\n              </div>\n            </div>\n            <div class=\"horario\">\n              <div class=\"informacoes\">\n                <div class=\"local\">\n                  {{profissionais_horarios_disponibilidade.empresa}}\n                </div>\n              </div>\n              <div class=\"informacoes\" style=\"border-radius: 0 20px 20px 0;\">\n                <div class=\"local intercalacao\">\n                  {{profissionais_horarios_disponibilidade.hr_inicio}}\n                </div>\n              </div>\n            </div>\n            <div class=\"horario\">\n              <div style=\"flex: 28%\">\n                <button class=\"btn btn-primary\"\n                (click)=\"seleciona(profissionais_horarios_disponibilidade)\">Selecionar</button>\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n\n    </div>\n  </section>\n</ion-content>\n\n<app-footer></app-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_paginas_procedimento-selecionado_procedimento-selecionado_module_ts.js.map