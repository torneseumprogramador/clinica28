"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_paginas_procedimentos-externos_procedimentos-externos_module_ts"],{

/***/ 2449:
/*!*****************************************************************************************!*\
  !*** ./src/app/paginas/procedimentos-externos/procedimentos-externos-routing.module.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProcedimentosExternosPageRoutingModule": () => (/* binding */ ProcedimentosExternosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _procedimentos_externos_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./procedimentos-externos.page */ 6660);




const routes = [
    {
        path: '',
        component: _procedimentos_externos_page__WEBPACK_IMPORTED_MODULE_0__.ProcedimentosExternosPage
    }
];
let ProcedimentosExternosPageRoutingModule = class ProcedimentosExternosPageRoutingModule {
};
ProcedimentosExternosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProcedimentosExternosPageRoutingModule);



/***/ }),

/***/ 9220:
/*!*********************************************************************************!*\
  !*** ./src/app/paginas/procedimentos-externos/procedimentos-externos.module.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProcedimentosExternosPageModule": () => (/* binding */ ProcedimentosExternosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _procedimentos_externos_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./procedimentos-externos-routing.module */ 2449);
/* harmony import */ var _procedimentos_externos_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./procedimentos-externos.page */ 6660);
/* harmony import */ var src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/componentes/carrinho/carrinho.component */ 8752);
/* harmony import */ var src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/componentes/footer/footer.component */ 202);
/* harmony import */ var src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/componentes/header/header.component */ 4944);
/* harmony import */ var src_app_componentes_modal_procedimento_modal_procedimento_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/componentes/modal-procedimento/modal-procedimento.component */ 6907);











let ProcedimentosExternosPageModule = class ProcedimentosExternosPageModule {
};
ProcedimentosExternosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_8__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonicModule,
            _procedimentos_externos_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProcedimentosExternosPageRoutingModule
        ],
        declarations: [
            src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_4__.HeaderComponent, src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterComponent, src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_2__.CarrinhoComponent,
            src_app_componentes_modal_procedimento_modal_procedimento_component__WEBPACK_IMPORTED_MODULE_5__.ModalProcedimentoComponent,
            _procedimentos_externos_page__WEBPACK_IMPORTED_MODULE_1__.ProcedimentosExternosPage
        ],
        exports: [
            src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_4__.HeaderComponent, src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterComponent, src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_2__.CarrinhoComponent,
            src_app_componentes_modal_procedimento_modal_procedimento_component__WEBPACK_IMPORTED_MODULE_5__.ModalProcedimentoComponent,
        ]
    })
], ProcedimentosExternosPageModule);



/***/ }),

/***/ 6660:
/*!*******************************************************************************!*\
  !*** ./src/app/paginas/procedimentos-externos/procedimentos-externos.page.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProcedimentosExternosPage": () => (/* binding */ ProcedimentosExternosPage)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _procedimentos_externos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./procedimentos-externos.page.html?ngResource */ 8655);
/* harmony import */ var _procedimentos_externos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./procedimentos-externos.page.scss?ngResource */ 7561);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_services_carrinho_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/carrinho.service */ 2136);
/* harmony import */ var src_app_services_grupoService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/grupoService */ 5314);
/* harmony import */ var src_app_services_localConsultaService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/localConsultaService */ 2417);
/* harmony import */ var src_app_services_modalService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/modalService */ 4704);
/* harmony import */ var src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/pacienteService */ 8839);
/* harmony import */ var src_app_services_procedimentoService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/procedimentoService */ 3247);
/* harmony import */ var src_app_services_tempService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/tempService */ 6685);














let ProcedimentosExternosPage = class ProcedimentosExternosPage {
  constructor(http, route, router, carrinhoService) {
    this.http = http;
    this.router = router;
    this.carrinhoService = carrinhoService;
    this.grupos = [];
    this.grupoId = 0;
    this.nomeProcedimento = '';
    this.procedimentos = [];
    this.procedimentosSelecionados = [];
    this.msg_procedimentos = '';
    this.mostrarModal = false;
    route.params.subscribe(val => {
      this.carrinhoService.carregaQuantidade();
    });

    if (!src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_7__.PacienteServico.logado()) {
      this.router.navigateByUrl('/login');
    }

    this.paciente = src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_7__.PacienteServico.getSessao();
  }

  ngOnInit() {
    this.carregaGrupos();
    this.procedimentosSelecionados = src_app_services_tempService__WEBPACK_IMPORTED_MODULE_9__.TempService.getTempObjects('procedimentosSelecionados');
  }

  carregaGrupos() {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.grupos = yield new src_app_services_grupoService__WEBPACK_IMPORTED_MODULE_4__.GrupoService(_this.http).todos();
    })();
  }

  valorTotal() {
    if (this.procedimentosSelecionados.length == 0) {
      return 0;
    }

    let valor = 0;
    this.procedimentosSelecionados.forEach(procedimento => {
      valor = Number(valor) + Number(procedimento.valor_procedimento);
    });
    return valor;
  }

  updateSelecionados(procedimentos) {
    this.procedimentosSelecionados = procedimentos;
    this.procedimentos.forEach(proc => {
      //@ts-ignore
      proc.checked = undefined;
      this.procedimentosSelecionados.forEach(procSelecionado => {
        if (procSelecionado.id === proc.id) {
          //@ts-ignore
          proc.checked = true;
        }
      });
    });
    src_app_services_tempService__WEBPACK_IMPORTED_MODULE_9__.TempService.setTempObjects('procedimentosSelecionados', this.procedimentosSelecionados);
  }

  prosseguir() {
    this.router.navigateByUrl('/procedimentos-externos/selecionados');
  }

  seleciona(procedimento, elen) {
    if (elen.checked) {
      if (procedimento.externo === 0) {
        elen.checked = false;
        src_app_services_modalService__WEBPACK_IMPORTED_MODULE_6__.ModalService.show('Procedimentos', `
        <p>
          <b>ATENÇÃO</b><br>
          Esse procedimento pode requerer pedido médico, em caso de dúvidas entre em contato. <br>
          Você será redirecionado para que possa escolher um horário disponível, o agendamento será confirmado após o pagamento.
        </p>
        `, 'Prosseguir', false, true, () => {
          this.router.navigateByUrl(`/especialidade/${this.grupo.especialidade_id}/profissional/${procedimento.profissional_id}/procedimento-grupo/${procedimento.idgrupo}?procedimento_id=${procedimento.id}`);
        });
        return;
      } //@ts-ignore


      procedimento.checked = true;
      this.procedimentosSelecionados.push(procedimento);
    } else {
      //@ts-ignore
      procedimento.checked = undefined;
      this.procedimentosSelecionados = this.procedimentosSelecionados.filter(obj => obj.id !== procedimento.id);
    }

    src_app_services_tempService__WEBPACK_IMPORTED_MODULE_9__.TempService.setTempObjects('procedimentosSelecionados', this.procedimentosSelecionados);
  }

  fecharModal() {
    this.mostrarModal = false;
  }

  verSelecionados() {
    this.mostrarModal = true;
  }

  buscar(timer = false) {
    if (!timer) {
      this.carregaProcedimentos();
      return;
    }

    clearInterval(this.interval);
    this.interval = setInterval(() => {
      clearInterval(this.interval);
      this.carregaProcedimentos();
    }, 500);
  }

  carregaProcedimentos() {
    var _this2 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      src_app_services_localConsultaService__WEBPACK_IMPORTED_MODULE_5__.LocalConsultaServico.removeLocal();
      _this2.profissional = _this2.profissional;
      _this2.grupo = yield new src_app_services_grupoService__WEBPACK_IMPORTED_MODULE_4__.GrupoService(_this2.http).get(_this2.grupoId);
      _this2.procedimentos = yield new src_app_services_procedimentoService__WEBPACK_IMPORTED_MODULE_8__.ProcedimentoServico(_this2.http).todosPorGrupoId(_this2.grupoId, _this2.nomeProcedimento);
      _this2.msg_procedimentos = _this2.procedimentos.length === 0 ? 'Nenhum procedimento encontrado' : '';
    })();
  }

};

ProcedimentosExternosPage.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_10__.HttpClient
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.Router
}, {
  type: src_app_services_carrinho_service__WEBPACK_IMPORTED_MODULE_3__.CarrinhoService
}];

ProcedimentosExternosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
  selector: 'app-procedimentos-externos',
  template: _procedimentos_externos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_procedimentos_externos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ProcedimentosExternosPage);


/***/ }),

/***/ 5314:
/*!******************************************!*\
  !*** ./src/app/services/grupoService.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GrupoService": () => (/* binding */ GrupoService)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ 2340);
/* harmony import */ var _loadService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./loadService */ 6521);
/* harmony import */ var _pacienteService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pacienteService */ 8839);





class GrupoService {
  constructor(http) {
    this.http = http;
  }

  todos() {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        let data = yield _this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/procedimentos_grupos.json`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  get(grupoId) {
    var _this2 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        let data = yield _this2.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/procedimentos_grupos/${grupoId}.json`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

}

/***/ }),

/***/ 7561:
/*!********************************************************************************************!*\
  !*** ./src/app/paginas/procedimentos-externos/procedimentos-externos.page.scss?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

module.exports = ".main-area .horario {\n  background-color: #0d00ff;\n  color: #fff;\n  text-transform: uppercase;\n  font-weight: bold;\n  border-bottom: 0px;\n}\n\n.main-area .horario .informacoes .local input[type=checkbox] {\n  background-color: #ff5a00;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2NlZGltZW50b3MtZXh0ZXJub3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kseUJBQUE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBQ0o7O0FBRUE7RUFDSSx5QkFBQTtBQUNKIiwiZmlsZSI6InByb2NlZGltZW50b3MtZXh0ZXJub3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1haW4tYXJlYSAuaG9yYXJpb3tcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMGQwMGZmO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgYm9yZGVyLWJvdHRvbTogMHB4O1xufVxuXG4ubWFpbi1hcmVhIC5ob3JhcmlvIC5pbmZvcm1hY29lcyAubG9jYWwgaW5wdXRbdHlwZT1cImNoZWNrYm94XCJde1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZjVhMDA7XG59Il19 */";

/***/ }),

/***/ 8655:
/*!********************************************************************************************!*\
  !*** ./src/app/paginas/procedimentos-externos/procedimentos-externos.page.html?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header></app-header>\n\n<ion-content [fullscreen]=\"true\">\n  <section class=\"main-area text-center\">\n    <div class=\"titulo-local\">\n      <div class=\"texto\">Nossos Procedimentos</div>\n      <div class=\"icon-marca\">\n        <img src=\"assets/images/marca/elemento-branco.png\" alt=\"elemento\">\n      </div>\n    </div>\n\n    <br><br>\n\n    <div id=\"nossos-procedimentos\">\n      <div class=\"exames\">\n        <select id=\"grupo\" [(ngModel)]=\"grupoId\" (change)=\"buscar()\" name=\"grupoId\" class=\"select-area cem_porcento\">\n          <option value=\"0\">[Selecione o tipo de exame]</option>\n          <option *ngFor=\"let grupo of grupos\" value=\"{{grupo.id}}\">\n            {{grupo.nome}}</option>\n        </select>\n      </div>\n      <div class=\"procedimentos-informacoes\">\n        <div class=\"acoes\">\n          <form (submit)=\"buscar()\">\n            <div class=\"buscas\">\n              <input type=\"text\" class=\"box cem_porcento\" (keyup)=\"buscar(true)\" [(ngModel)]=\"nomeProcedimento\" id=\"nomeProcedimento\" name=\"nomeProcedimento\" placeholder=\"Digite o procedimento\">\n              <button type=\"submit\" class=\"btn\"><img src=\"assets/images/icones/loupe_79257.png\" alt=\"loupe_79257\"></button>\n            </div>\n          </form>\n        </div>\n        <div class=\"acoes\">\n          <div class=\"valor\">\n            {{valorTotal() | currency}}\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <div id=\"horarios\">\n      <button (click)=\"verSelecionados()\" class=\"btn btn-primary\">Ver Selecionados</button>\n      <div *ngIf=\"msg_procedimentos\" class=\"alert alert-warning\">{{msg_procedimentos}}</div>\n      <div *ngIf=\"procedimentos && procedimentos.length > 0\">\n        <div class=\"actions text-center\"  style=\"margin: 0;\">\n          <button (click)=\"prosseguir()\" class=\"btn btn-warning\"  [disabled]=\"!procedimentosSelecionados || procedimentosSelecionados.length == 0\">Prosseguir</button>\n        </div>\n\n        <div class=\"grupo-horarios pc-externo\">\n          <div class=\"cabecalho-horarios\">\n            <div class=\"options\">Procedimento/Valor/Profissional</div>\n          </div>\n          <div *ngFor=\"let procedimento of procedimentos\" style=\"border-bottom: 8px solid #fff;\">\n            <table style=\"width: 100%;\">\n              <tr style=\"border-bottom: 1px solid #fff;\">\n                <td style=\"background-color: #707070;width: 25%;\">\n                  <div class=\"horario\" style=\"display: inline-block;\">\n                    <div class=\"informacoes intercalacao\">\n                      <div class=\"local intercalacao\">\n                        <p>Selecionar</p>\n                        <input type=\"checkbox\" checked=\"{{procedimento.checked}}\" (click)=\"seleciona(procedimento, $event.target)\" name=\"selecionaProcedimento\" >\n                      </div>\n                    </div>\n                  </div>\n                </td>\n                <td style=\"background-color: #707070;\">\n                  <div class=\"horario\" style=\"display: inline-block;\">\n                    <div class=\"horario\">\n                      <div class=\"informacoes\">\n                        <div class=\"local\" style=\"background-color: #ff5a00;font-size: 14px;\">\n                          {{procedimento.procedimento}}\n                        </div>\n                      </div>\n                    </div>\n                    <div class=\"horario\">\n                      <div class=\"informacoes\">\n                        <div class=\"local\" style=\"padding: 8px;\">\n                          {{procedimento.valor_procedimento | currency : 'BRL'}}\n                        </div>\n                      </div>\n                      <div class=\"informacoes\">\n                        <div class=\"local\" style=\"border-radius: 0;\">\n                          {{procedimento.nome_profissional}}\n                        </div>\n                      </div>\n                    </div>\n                  </div>\n                </td>\n              </tr>\n            </table>\n          </div>\n        </div>\n      </div>\n    </div>\n  </section>\n\n\n</ion-content>\n\n<app-footer></app-footer>\n\n\n<div *ngIf=\"mostrarModal\" id=\"modalProcedimentos\" class=\"modal\">\n  <div>\n    <button (click)=\"fecharModal()\" class=\"btn fechar\">Fechar</button>\n    <app-modal-procedimento [procedimentosSelecionados]=\"procedimentosSelecionados\" (resposta)=\"updateSelecionados($event)\"></app-modal-procedimento>\n  </div>\n</div>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_paginas_procedimentos-externos_procedimentos-externos_module_ts.js.map