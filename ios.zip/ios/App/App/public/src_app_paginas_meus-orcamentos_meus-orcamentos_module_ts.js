"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_paginas_meus-orcamentos_meus-orcamentos_module_ts"],{

/***/ 3768:
/*!***************************************************************************!*\
  !*** ./src/app/paginas/meus-orcamentos/meus-orcamentos-routing.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MeusOrcamentosPageRoutingModule": () => (/* binding */ MeusOrcamentosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _meus_orcamentos_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./meus-orcamentos.page */ 6254);




const routes = [
    {
        path: '',
        component: _meus_orcamentos_page__WEBPACK_IMPORTED_MODULE_0__.MeusOrcamentosPage
    }
];
let MeusOrcamentosPageRoutingModule = class MeusOrcamentosPageRoutingModule {
};
MeusOrcamentosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MeusOrcamentosPageRoutingModule);



/***/ }),

/***/ 9012:
/*!*******************************************************************!*\
  !*** ./src/app/paginas/meus-orcamentos/meus-orcamentos.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MeusOrcamentosPageModule": () => (/* binding */ MeusOrcamentosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _meus_orcamentos_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./meus-orcamentos-routing.module */ 3768);
/* harmony import */ var _meus_orcamentos_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./meus-orcamentos.page */ 6254);
/* harmony import */ var src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/componentes/header/header.component */ 4944);
/* harmony import */ var src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/componentes/footer/footer.component */ 202);
/* harmony import */ var src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/componentes/carrinho/carrinho.component */ 8752);










let MeusOrcamentosPageModule = class MeusOrcamentosPageModule {
};
MeusOrcamentosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _meus_orcamentos_routing_module__WEBPACK_IMPORTED_MODULE_0__.MeusOrcamentosPageRoutingModule
        ],
        declarations: [
            src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_2__.HeaderComponent, src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterComponent, src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_4__.CarrinhoComponent, _meus_orcamentos_page__WEBPACK_IMPORTED_MODULE_1__.MeusOrcamentosPage
        ]
    })
], MeusOrcamentosPageModule);



/***/ }),

/***/ 6254:
/*!*****************************************************************!*\
  !*** ./src/app/paginas/meus-orcamentos/meus-orcamentos.page.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MeusOrcamentosPage": () => (/* binding */ MeusOrcamentosPage)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _meus_orcamentos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./meus-orcamentos.page.html?ngResource */ 7740);
/* harmony import */ var _meus_orcamentos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./meus-orcamentos.page.scss?ngResource */ 123);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_services_modalService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/modalService */ 4704);
/* harmony import */ var src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/pacienteService */ 8839);
/* harmony import */ var src_app_services_tempService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/tempService */ 6685);










let MeusOrcamentosPage = class MeusOrcamentosPage {
  constructor(http, route, router) {
    this.http = http;
    this.router = router;
    this.orcamentosSelecionados = [];
  }

  ngOnInit() {
    src_app_services_tempService__WEBPACK_IMPORTED_MODULE_5__.TempService.setTempObjects('orcamentosSelecionados', []);
    this.carrega();
  }

  carrega() {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.orcamentos = yield new src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_4__.PacienteServico(_this.http).orcamentos(src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_4__.PacienteServico.getSessao().id);
    })();
  }

  prosseguir() {
    this.router.navigateByUrl('/procedimentos-orcamentos');
  }

  seleciona(orcamento, elen) {
    if (elen.checked) {
      if (orcamento.externo === 0) {
        elen.checked = false;
        src_app_services_modalService__WEBPACK_IMPORTED_MODULE_3__.ModalService.show('Procedimento', `
        <p>
          <b>ATENÇÃO</b><br>
          Esse procedimento pode requerer pedido médico, em caso de dúvidas entre em contato. <br>
          Você será redirecionado para que possa escolher um horário disponível, o agendamento será confirmado após o pagamento.
        </p>
        `, 'Prosseguir', false, true, () => {
          this.router.navigateByUrl(`/especialidade/${orcamento.especialidade_id}/profissional/${orcamento.profissional_id}/procedimento-grupo/${orcamento.idgrupo}?procedimento_id=${orcamento.procedimento_id}`);
        });
        return;
      } //@ts-ignore


      orcamento.checked = true;
      this.orcamentosSelecionados.push(orcamento);
    } else {
      //@ts-ignore
      orcamento.checked = undefined;
      this.orcamentosSelecionados = this.orcamentosSelecionados.filter(obj => obj.id !== orcamento.id);
    }

    src_app_services_tempService__WEBPACK_IMPORTED_MODULE_5__.TempService.setTempObjects('orcamentosSelecionados', this.orcamentosSelecionados);
  }

  valorTotal() {
    let valor = 0;

    for (const item of this.orcamentos) {
      valor = Number(valor) + Number(item.procedimento_valor);
    }

    return valor;
  }

  valorTotalSelecionado() {
    if (this.orcamentosSelecionados.length === 0) {
      return 0;
    }

    ;
    let valor = 0;
    this.orcamentosSelecionados.forEach(orcamento => {
      valor = Number(valor) + Number(orcamento.procedimento_valor);
    });
    return valor;
  }

};

MeusOrcamentosPage.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router
}];

MeusOrcamentosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-meus-orcamentos',
  template: _meus_orcamentos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_meus_orcamentos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], MeusOrcamentosPage);


/***/ }),

/***/ 123:
/*!******************************************************************************!*\
  !*** ./src/app/paginas/meus-orcamentos/meus-orcamentos.page.scss?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = ".orcamento_botao {\n  font-size: 14px;\n  width: 100px;\n  height: 50px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldXMtb3JjYW1lbnRvcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxlQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUFDSiIsImZpbGUiOiJtZXVzLW9yY2FtZW50b3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm9yY2FtZW50b19ib3Rhb3tcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgd2lkdGg6IDEwMHB4O1xuICAgIGhlaWdodDogNTBweDtcbn0iXX0= */";

/***/ }),

/***/ 7740:
/*!******************************************************************************!*\
  !*** ./src/app/paginas/meus-orcamentos/meus-orcamentos.page.html?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = "<app-header></app-header>\n\n<ion-content>\n  <section class=\"main-area text-center\">\n    <div class=\"titulo-local\">\n      <div class=\"texto\">Meus Orçamentos</div>\n      <div class=\"icon-marca\">\n        <img src=\"assets/images/marca/elemento-branco.png\" alt=\"elemento\">\n      </div>\n    </div>\n\n    <br><br>\n\n    <div *ngIf=\"!orcamentos || orcamentos.length === 0\" class=\"alert alert-warning\">Nenhum orçamento!</div>\n    <div *ngIf=\"orcamentos && orcamentos.length > 0\" style=\"border-bottom: 8px solid #fff;\">\n      <div id=\"horarios\">\n        <div class=\"grupo-horarios\">\n          <div class=\"cabecalho-horarios\" style=\"padding: 10px; text-align: end;\">\n            <div class=\"options\">PROCEDIMENTO / PACIENTE <br> DATA DE VALIDADE / VALOR</div>\n          </div>\n          <div *ngFor=\"let item of orcamentos\" style=\"border-bottom: 8px solid #fff;\">\n            <table style=\"width: 100%;\">\n              <tr style=\"border-bottom: 1px solid #fff;\">\n                <td style=\"background-color: #707070;width: 25%;\">\n                  <div class=\"horario\" style=\"display: inline-block;border: none;\">\n                    <div class=\"informacoes intercalacao\">\n                      <div class=\"local intercalacao\">\n                        <p>Selecionar</p>\n                        <input type=\"checkbox\" checked=\"{{item.checked}}\" (click)=\"seleciona(item, $event.target)\" name=\"selecionaProcedimento\" >\n                      </div>\n                    </div>\n                  </div>\n                </td>\n                <td style=\"background-color: #707070;\">\n                  <div class=\"horario\">\n                    <div class=\"informacoes\">\n                      <div class=\"local\" style=\"background-color: #ff5a00;font-size: 14px;\">\n                        {{item.procedimento_nome}}\n                      </div>\n                    </div>\n                  </div>\n\n                  <div class=\"horario\">\n                    <div class=\"informacoes\">\n                      <div class=\"local\">\n                        {{item.paciente_nome}}\n                      </div>\n                    </div>\n                  </div>\n\n                  <div class=\"horario\">\n                    <div class=\"informacoes\">\n                      <div class=\"local\" style=\"border-radius: 0;\">\n                        {{item.datavalidade | date: 'dd/MM/yyyy'}}\n                      </div>\n                    </div>\n                    <div class=\"informacoes\">\n                      <div class=\"local\" style=\"border-radius: 0;\">\n                        {{item.procedimento_valor | currency : 'BRL'}}\n                      </div>\n                    </div>\n                  </div>\n                </td>\n              </tr>\n            </table>\n          </div>\n        </div>\n      </div>\n\n      <div class=\"valor\">\n        <div class=\"valor-carrinho\">\n          <strong><span>Total:</span> {{valorTotal() | currency : 'BRL'}}</strong>\n        </div>\n\n        <div class=\"valor-carrinho\">\n          <strong><span>Total Selecionados:</span> {{valorTotalSelecionado() | currency : 'BRL'}}</strong>\n        </div>\n      </div>\n\n      <div class=\"actions text-center\">\n        <button (click)=\"prosseguir()\" class=\"btn btn-warning\"  [disabled]=\"!orcamentosSelecionados || orcamentosSelecionados.length === 0\">Prosseguir</button>\n      </div>\n    </div>\n\n\n  </section>\n</ion-content>\n\n<app-footer></app-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_paginas_meus-orcamentos_meus-orcamentos_module_ts.js.map