"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_paginas_minhas-compras-detalhes_minhas-compras-detalhes_module_ts"],{

/***/ 8908:
/*!*******************************************************************************************!*\
  !*** ./src/app/paginas/minhas-compras-detalhes/minhas-compras-detalhes-routing.module.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MinhasComprasDetalhesPageRoutingModule": () => (/* binding */ MinhasComprasDetalhesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _minhas_compras_detalhes_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./minhas-compras-detalhes.page */ 8130);




const routes = [
    {
        path: '',
        component: _minhas_compras_detalhes_page__WEBPACK_IMPORTED_MODULE_0__.MinhasComprasDetalhesPage
    }
];
let MinhasComprasDetalhesPageRoutingModule = class MinhasComprasDetalhesPageRoutingModule {
};
MinhasComprasDetalhesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MinhasComprasDetalhesPageRoutingModule);



/***/ }),

/***/ 9060:
/*!***********************************************************************************!*\
  !*** ./src/app/paginas/minhas-compras-detalhes/minhas-compras-detalhes.module.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MinhasComprasDetalhesPageModule": () => (/* binding */ MinhasComprasDetalhesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _minhas_compras_detalhes_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./minhas-compras-detalhes-routing.module */ 8908);
/* harmony import */ var _minhas_compras_detalhes_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./minhas-compras-detalhes.page */ 8130);
/* harmony import */ var src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/componentes/header/header.component */ 4944);
/* harmony import */ var src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/componentes/footer/footer.component */ 202);
/* harmony import */ var src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/componentes/carrinho/carrinho.component */ 8752);
/* harmony import */ var src_app_pipes_status_pedido_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/pipes/status-pedido.pipe */ 6889);











let MinhasComprasDetalhesPageModule = class MinhasComprasDetalhesPageModule {
};
MinhasComprasDetalhesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_8__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonicModule,
            _minhas_compras_detalhes_routing_module__WEBPACK_IMPORTED_MODULE_0__.MinhasComprasDetalhesPageRoutingModule
        ],
        declarations: [
            src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_2__.HeaderComponent, src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterComponent, src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_4__.CarrinhoComponent, src_app_pipes_status_pedido_pipe__WEBPACK_IMPORTED_MODULE_5__.StatusPedidoPipe, _minhas_compras_detalhes_page__WEBPACK_IMPORTED_MODULE_1__.MinhasComprasDetalhesPage
        ]
    })
], MinhasComprasDetalhesPageModule);



/***/ }),

/***/ 8130:
/*!*********************************************************************************!*\
  !*** ./src/app/paginas/minhas-compras-detalhes/minhas-compras-detalhes.page.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MinhasComprasDetalhesPage": () => (/* binding */ MinhasComprasDetalhesPage)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _minhas_compras_detalhes_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./minhas-compras-detalhes.page.html?ngResource */ 4824);
/* harmony import */ var _minhas_compras_detalhes_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./minhas-compras-detalhes.page.scss?ngResource */ 4372);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_helpers_servico__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/helpers/servico */ 9000);
/* harmony import */ var src_app_services_clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/clinicaProcedimentoService */ 4731);
/* harmony import */ var src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/pacienteService */ 8839);










let MinhasComprasDetalhesPage = class MinhasComprasDetalhesPage {
  constructor(http, routerParams) {
    this.http = http;
    this.routerParams = routerParams;
  }

  ngOnInit() {
    this.carrega();
  }

  carrega() {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      clearInterval(src_app_helpers_servico__WEBPACK_IMPORTED_MODULE_3__.Servico.pedidoInterval);
      const pedidoId = _this.routerParams.snapshot.params.pedido_id;
      _this.pedido = yield new src_app_services_clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_4__.ClinicaProcedimentoService(_this.http).pedido(src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_5__.PacienteServico.getSessao().id, pedidoId);
      src_app_helpers_servico__WEBPACK_IMPORTED_MODULE_3__.Servico.pedidoInterval = setInterval( /*#__PURE__*/(0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
        yield _this.carrega();
      }), 30000);
      _this.itens = yield new src_app_services_clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_4__.ClinicaProcedimentoService(_this.http).itensPedido(src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_5__.PacienteServico.getSessao().id, pedidoId);
    })();
  }

  enviarWhatsApp() {
    var _this2 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const pedidoId = _this2.routerParams.snapshot.params.pedido_id;
      yield new src_app_services_clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_4__.ClinicaProcedimentoService(_this2.http).enviarWhatsApp(src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_5__.PacienteServico.getSessao().id, pedidoId);
      alert('Dados enviados com sucesso. Em instantes você receberá em seu celular.');
    })();
  }

};

MinhasComprasDetalhesPage.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute
}];

MinhasComprasDetalhesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-minhas-compras-detalhes',
  template: _minhas_compras_detalhes_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_minhas_compras_detalhes_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], MinhasComprasDetalhesPage);


/***/ }),

/***/ 4372:
/*!**********************************************************************************************!*\
  !*** ./src/app/paginas/minhas-compras-detalhes/minhas-compras-detalhes.page.scss?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtaW5oYXMtY29tcHJhcy1kZXRhbGhlcy5wYWdlLnNjc3MifQ== */";

/***/ }),

/***/ 4824:
/*!**********************************************************************************************!*\
  !*** ./src/app/paginas/minhas-compras-detalhes/minhas-compras-detalhes.page.html?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header></app-header>\n\n<ion-content>\n  <section class=\"main-area text-center\">\n    <div class=\"titulo-local\">\n      <div class=\"texto\">Detalhe Compras</div>\n      <div class=\"icon-marca\">\n        <img src=\"assets/images/marca/elemento-branco.png\" alt=\"elemento\">\n      </div>\n    </div>\n\n    <br><br>\n    <div *ngIf=\"!pedido\" class=\"alert alert-warning\">Pedido não encontrado!</div>\n    <div *ngIf=\"pedido\">\n      <div class=\"informe-pedidos\">\n        <h1>Seu pedido:</h1>\n        <hr>\n        <div class=\"dados\">\n            <div style=\"flex: 50%\">\n              <div><b>Código:</b> {{pedido.cd_venda}}</div>\n              <div><b>Data:</b> {{pedido.data | date: 'dd/MM/yyyy'}}</div>\n              <div><b>Valor:</b> {{pedido.valor_final | currency}}</div>\n              <div><b>Status:</b> {{pedido.status | statusPedido}}</div>\n              <div *ngIf=\"pedido.status === 2\">\n                <button class=\"btn btn-warning\" (click)=\"enviarWhatsApp()\">Reenviar WhatsApp</button>\n              </div>\n            </div>\n            <div style=\"flex: 50%\">\n              <div *ngIf=\"pedido.status === 4\" class=\"text-center\">\n                <img src=\"{{pedido.pix_qrcode}}\" alt=\"pix_qrcode\" style=\"width: 25%;\">\n                <p>{{pedido.pix_qrcode_text}}</p>\n              </div>\n            </div>\n        </div>\n      </div>\n\n      <hr>\n      <div id=\"horarios\">\n        <div class=\"grupo-horarios\">\n          <div class=\"cabecalho-horarios\">\n            <div class=\"options-carrinho\">\n              Data/Paciente<br>\n              Procedimento/Profissional\n            </div>\n            <div class=\"options-carrinho\">\n              Código/Unidade<br>\n              A partir das/Valor\n            </div>\n          </div>\n\n          <div *ngFor=\"let item of itens\" style=\"border-bottom: 10px solid #fff;\">\n            <div class=\"horario\">\n              <div class=\"informacoes carrinho\">\n                <div class=\"local\">\n                  {{item.data}}\n                </div>\n              </div>\n\n              <div class=\"informacoes carrinho intercalacao\">\n                <div class=\"local intercalacao\">\n                  {{item.cd_agendamento}}\n                </div>\n              </div>\n            </div>\n            <div class=\"horario\">\n              <div class=\"informacoes carrinho\">\n                <div class=\"local\" style=\"font-size: 1.0rem;\">\n                  {{item.paciente}}\n                </div>\n              </div>\n\n              <div class=\"informacoes carrinho intercalacao\">\n                <div *ngIf=\"item.cd_agendamento\" class=\"local intercalacao\" style=\"font-size: 1.0rem;\">\n                  {{item.unidade}}\n                </div>\n                <div *ngIf=\"!item.cd_agendamento\" class=\"local intercalacao\" style=\"font-size: 1.0rem;\"></div>\n              </div>\n\n            </div>\n            <div class=\"horario\">\n              <div class=\"informacoes carrinho\">\n                <div class=\"local\" style=\"font-size: 1.0rem;\">\n                  {{item.procedimento}}\n                </div>\n              </div>\n\n              <div class=\"informacoes carrinho intercalacao\">\n                <div class=\"local intercalacao\">\n                  {{item.inicio}}\n                </div>\n              </div>\n\n            </div>\n            <div class=\"horario\">\n              <div class=\"informacoes carrinho\">\n                <div class=\"local\" style=\"font-size: 1.0rem;\">\n                  {{item.profissional}}\n                </div>\n              </div>\n\n              <div class=\"informacoes carrinho intercalacao\">\n                <div class=\"local intercalacao\">\n                  {{item.valor_final | currency : 'BRL'}}\n                </div>\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </section>\n</ion-content>\n\n<app-footer></app-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_paginas_minhas-compras-detalhes_minhas-compras-detalhes_module_ts.js.map