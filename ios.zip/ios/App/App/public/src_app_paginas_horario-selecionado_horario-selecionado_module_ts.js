"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_paginas_horario-selecionado_horario-selecionado_module_ts"],{

/***/ 3369:
/*!***********************************************************************************!*\
  !*** ./src/app/paginas/horario-selecionado/horario-selecionado-routing.module.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HorarioSelecionadoPageRoutingModule": () => (/* binding */ HorarioSelecionadoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _horario_selecionado_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./horario-selecionado.page */ 6061);




const routes = [
    {
        path: '',
        component: _horario_selecionado_page__WEBPACK_IMPORTED_MODULE_0__.HorarioSelecionadoPage
    }
];
let HorarioSelecionadoPageRoutingModule = class HorarioSelecionadoPageRoutingModule {
};
HorarioSelecionadoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
        declarations: []
    })
], HorarioSelecionadoPageRoutingModule);



/***/ }),

/***/ 111:
/*!***************************************************************************!*\
  !*** ./src/app/paginas/horario-selecionado/horario-selecionado.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HorarioSelecionadoPageModule": () => (/* binding */ HorarioSelecionadoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _horario_selecionado_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./horario-selecionado-routing.module */ 3369);
/* harmony import */ var _horario_selecionado_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./horario-selecionado.page */ 6061);
/* harmony import */ var ngx_mask__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-mask */ 446);
/* harmony import */ var src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/componentes/carrinho/carrinho.component */ 8752);
/* harmony import */ var src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/componentes/header/header.component */ 4944);
/* harmony import */ var src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/componentes/footer/footer.component */ 202);
/* harmony import */ var src_app_pipes_formata_cpf_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/pipes/formata-cpf.pipe */ 5601);
/* harmony import */ var src_app_pipes_formata_rg_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/pipes/formata-rg.pipe */ 8088);
/* harmony import */ var src_app_pipes_formata_sexo_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/pipes/formata-sexo.pipe */ 1089);
/* harmony import */ var src_app_pipes_formata_telefone_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/pipes/formata-telefone.pipe */ 683);















let HorarioSelecionadoPageModule = class HorarioSelecionadoPageModule {
};
HorarioSelecionadoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.NgModule)({
        imports: [
            ngx_mask__WEBPACK_IMPORTED_MODULE_11__.NgxMaskModule.forRoot(),
            _angular_common__WEBPACK_IMPORTED_MODULE_12__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.IonicModule,
            _horario_selecionado_routing_module__WEBPACK_IMPORTED_MODULE_0__.HorarioSelecionadoPageRoutingModule
        ],
        declarations: [
            src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_3__.HeaderComponent, src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_4__.FooterComponent, src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_2__.CarrinhoComponent,
            _horario_selecionado_page__WEBPACK_IMPORTED_MODULE_1__.HorarioSelecionadoPage,
            src_app_pipes_formata_sexo_pipe__WEBPACK_IMPORTED_MODULE_7__.FormataSexoPipe, src_app_pipes_formata_cpf_pipe__WEBPACK_IMPORTED_MODULE_5__.FormataCpfPipe, src_app_pipes_formata_rg_pipe__WEBPACK_IMPORTED_MODULE_6__.FormataRgPipe, src_app_pipes_formata_telefone_pipe__WEBPACK_IMPORTED_MODULE_8__.FormataTelefonePipe
        ],
        exports: [
            src_app_pipes_formata_sexo_pipe__WEBPACK_IMPORTED_MODULE_7__.FormataSexoPipe, src_app_pipes_formata_cpf_pipe__WEBPACK_IMPORTED_MODULE_5__.FormataCpfPipe, src_app_pipes_formata_rg_pipe__WEBPACK_IMPORTED_MODULE_6__.FormataRgPipe, src_app_pipes_formata_telefone_pipe__WEBPACK_IMPORTED_MODULE_8__.FormataTelefonePipe
        ],
    })
], HorarioSelecionadoPageModule);



/***/ }),

/***/ 6061:
/*!*************************************************************************!*\
  !*** ./src/app/paginas/horario-selecionado/horario-selecionado.page.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HorarioSelecionadoPage": () => (/* binding */ HorarioSelecionadoPage)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _horario_selecionado_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./horario-selecionado.page.html?ngResource */ 7216);
/* harmony import */ var _horario_selecionado_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./horario-selecionado.page.scss?ngResource */ 8777);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_services_cepService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/cepService */ 7326);
/* harmony import */ var src_app_services_clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/clinicaProcedimentoService */ 4731);
/* harmony import */ var src_app_services_erroService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/erroService */ 8592);
/* harmony import */ var src_app_services_especialidadeService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/especialidadeService */ 2930);
/* harmony import */ var src_app_services_localConsultaService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/localConsultaService */ 2417);
/* harmony import */ var src_app_services_modalService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/modalService */ 4704);
/* harmony import */ var src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/pacienteService */ 8839);
/* harmony import */ var src_app_services_procedimentoService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/procedimentoService */ 3247);
/* harmony import */ var src_app_services_profissionaisHorariosDisponibilidadeServico__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/profissionaisHorariosDisponibilidadeServico */ 7103);
/* harmony import */ var src_app_services_profissionalService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/services/profissionalService */ 5268);
/* harmony import */ var src_app_services_scrollService__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/services/scrollService */ 7093);


















let HorarioSelecionadoPage = class HorarioSelecionadoPage {
  constructor(http, routerParams) {
    this.http = http;
    this.routerParams = routerParams;
    this.paciente = src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_9__.PacienteServico.getSessao();
    this.cadastro = false;
  }

  ngOnInit() {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.cpf = _this.paciente.cpf; // this.paciente.rg = undefined;
      // this.paciente.sexo = 0;

      _this.especialidade = yield new src_app_services_especialidadeService__WEBPACK_IMPORTED_MODULE_6__.EspecialidadeServico(_this.http).get(_this.routerParams.snapshot.params.especialidade_id);
      _this.profissional = yield new src_app_services_profissionalService__WEBPACK_IMPORTED_MODULE_12__.ProfissionalServico(_this.http).get(_this.routerParams.snapshot.params.profissional_id);
      _this.procedimento = yield new src_app_services_procedimentoService__WEBPACK_IMPORTED_MODULE_10__.ProcedimentoServico(_this.http).get(_this.routerParams.snapshot.params.procedimento_id);
      _this.profissionais_horarios_disponibilidade = yield new src_app_services_profissionaisHorariosDisponibilidadeServico__WEBPACK_IMPORTED_MODULE_11__.ProfissionaisHorariosDisponibilidadeServico(_this.http).get(_this.routerParams.snapshot.params.profissionais_horarios_disponibilidade_id);
    })();
  }

  preencheCep() {
    new src_app_services_cepService__WEBPACK_IMPORTED_MODULE_3__.CepServico(this.http).set(this.paciente);
  }

  removePlaceholderDate(display) {
    const placeholderLabel = document.querySelector('.placeholder-label');
    placeholderLabel.style.display = display;
  }

  buscaCPF() {
    var _this2 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.mensagem = '';
      _this2.paciente = undefined;

      try {
        const pacientes = yield new src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_9__.PacienteServico(_this2.http).porCPF(_this2.cpf);

        if (pacientes.length > 0) {
          _this2.paciente = pacientes[0];

          if (!_this2.paciente.cep) {
            _this2.telaSalvarCadastro();
          }
        } else {
          _this2.mensagem = 'Paciente não encontrado!';
        }
      } catch (e) {
        _this2.mensagem = src_app_services_erroService__WEBPACK_IMPORTED_MODULE_5__.ErroServico.mensagemErro(e);
      }
    })();
  }

  naoEncontrado() {
    return this.mensagem.match(/não encontrado/) != null ? true : false;
  }

  telaSalvarCadastro() {
    if (!this.paciente || !this.paciente.id) {
      this.paciente = {};
      this.paciente.cpf = this.cpf;
      this.paciente.sexo = 0;
    }

    this.cadastro = true;
    this.mensagem_cadastro = '';
  }

  voltar() {
    var _this3 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.paciente = {};
      _this3.cadastro = false;
    })();
  }

  cadastrar() {
    var _this4 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this4.mensagem = '';
      _this4.mensagem_cadastro = '';

      if (!_this4.paciente.nome || _this4.paciente.nome === '') {
        _this4.mensagem_cadastro = 'Nome obrigatório';
        return;
      }

      if (!_this4.paciente.cpf || _this4.paciente.cpf === '') {
        _this4.mensagem_cadastro = 'CPF obrigatório';
        return;
      }

      if (!_this4.paciente.sexo || _this4.paciente.sexo.toString() === '0') {
        _this4.mensagem_cadastro = 'Sexo obrigatório';
        return;
      }

      if (!_this4.paciente.nome_mae || _this4.paciente.nome_mae === '') {
        _this4.mensagem_cadastro = 'Nome da mãe obrigatório';
        return;
      }

      if (!_this4.paciente.data_nascimento) {
        _this4.mensagem_cadastro = 'Data de Nascimento obrigatória';
        return;
      }

      if (!_this4.paciente.fone || _this4.paciente.fone === '') {
        _this4.mensagem_cadastro = 'Telefone obrigatório';
        return;
      }

      if (!_this4.paciente.endereco || _this4.paciente.endereco === '') {
        _this4.mensagem_cadastro = 'Endereço obrigatório';
        return;
      }

      if (!_this4.paciente.numero || _this4.paciente.numero === '') {
        _this4.mensagem_cadastro = 'Número obrigatório';
        return;
      }

      if (!_this4.paciente.bairro || _this4.paciente.bairro === '') {
        _this4.mensagem_cadastro = 'Bairro obrigatório';
        return;
      }

      if (!_this4.paciente.cidade || _this4.paciente.cidade === '') {
        _this4.mensagem_cadastro = 'Cidade obrigatório';
        return;
      }

      if (!_this4.paciente.uf || _this4.paciente.uf === '') {
        _this4.mensagem_cadastro = 'Estado obrigatório';
        return;
      }

      try {
        _this4.paciente.paciente_id_titular = src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_9__.PacienteServico.getSessao().id;
        _this4.paciente = yield new src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_9__.PacienteServico(_this4.http).salvar(_this4.paciente);
        _this4.cadastro = false;
        _this4.cpf = _this4.paciente.cpf;
      } catch (e) {
        _this4.mensagem_cadastro = src_app_services_erroService__WEBPACK_IMPORTED_MODULE_5__.ErroServico.mensagemErro(e);
        src_app_services_scrollService__WEBPACK_IMPORTED_MODULE_13__.ScrollServico.scroll('mensagemErro');
      }
    })();
  }

  addCarrinho() {
    var _this5 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (!_this5.permissaoIdadeAtendimento()) {
        console.log('permissão negada :>> ');
        _this5.mensagem_cadastro = 'Esse profissional não atende à essa FAIXA DE IDADE. Favor reinicie o processo e escolha outro profissional.';
        return;
      }

      try {
        const clinicaProcedimentoSalvar = {};
        clinicaProcedimentoSalvar.paciente_logado_id = src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_9__.PacienteServico.getSessao().id;
        clinicaProcedimentoSalvar.paciente_id = _this5.paciente.id;
        clinicaProcedimentoSalvar.profissionais_horarios_disponibilidade_id = _this5.profissionais_horarios_disponibilidade.id;
        clinicaProcedimentoSalvar.procedimento_id = _this5.procedimento.id;
        clinicaProcedimentoSalvar.especialidade_id = _this5.routerParams.snapshot.params.especialidade_id;
        clinicaProcedimentoSalvar.dados_atendimento = src_app_services_localConsultaService__WEBPACK_IMPORTED_MODULE_7__.LocalConsultaServico.getLocal();
        yield new src_app_services_clinicaProcedimentoService__WEBPACK_IMPORTED_MODULE_4__.ClinicaProcedimentoService(_this5.http).salvar(clinicaProcedimentoSalvar);
        src_app_services_modalService__WEBPACK_IMPORTED_MODULE_8__.ModalService.show('Adicionado no carrinho com sucesso!', 'Deseja adicionar outro precedimento?', 'Voltar para início', true, false, () => {
          window.location.href = '/home';
        });
      } catch (e) {
        _this5.mensagem_cadastro = src_app_services_erroService__WEBPACK_IMPORTED_MODULE_5__.ErroServico.mensagemErro(e);
        src_app_services_scrollService__WEBPACK_IMPORTED_MODULE_13__.ScrollServico.scroll('mensagemErro');
      }
    })();
  }

  permissaoIdadeAtendimento() {
    const idade_min = this.profissional.idade_min;
    const idade_max = this.profissional.idade_max;

    if (!idade_max) {
      return true;
    }

    const [ano, mes, dia] = this.paciente.data_nascimento.toString().split('-');
    const idade = this.idade(ano, mes, dia);

    if (idade_min <= idade && idade_max >= idade) {
      return true;
    }

    return false;
  }

  idade(ano_aniversario, mes_aniversario, dia_aniversario) {
    const d = new Date();
    const ano_atual = d.getFullYear();
    const mes_atual = d.getMonth() + 1;
    const dia_atual = d.getDate();
    ano_aniversario = +ano_aniversario;
    mes_aniversario = +mes_aniversario;
    dia_aniversario = +dia_aniversario;
    let quantos_anos = ano_atual - ano_aniversario;

    if (mes_atual < mes_aniversario || mes_atual === mes_aniversario && dia_atual < dia_aniversario) {
      quantos_anos--;
    }

    return quantos_anos < 0 ? 0 : quantos_anos;
  }

};

HorarioSelecionadoPage.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_14__.HttpClient
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_15__.ActivatedRoute
}];

HorarioSelecionadoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.Component)({
  selector: 'app-horario-selecionado',
  template: _horario_selecionado_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_horario_selecionado_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], HorarioSelecionadoPage);


/***/ }),

/***/ 4704:
/*!******************************************!*\
  !*** ./src/app/services/modalService.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalService": () => (/* binding */ ModalService)
/* harmony export */ });
class ModalService {
    static show(titulo, texto, textoBotao = 'Voltar para o site', carrinho = true, forceCloseModalShow = false, callback) {
        //@ts-ignore
        custonModal.open(titulo, texto, textoBotao, carrinho, forceCloseModalShow);
        //@ts-ignore
        custonModal.callback = callback;
    }
    static popup(image, numPopup) {
        //@ts-ignore
        custonPopup.open(image, numPopup);
    }
}


/***/ }),

/***/ 8777:
/*!**************************************************************************************!*\
  !*** ./src/app/paginas/horario-selecionado/horario-selecionado.page.scss?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

module.exports = "strong {\n  font-weight: bold;\n  font-size: 19px;\n}\n\n.input-container {\n  position: relative;\n}\n\n.date-input {\n  padding: 5px;\n}\n\n.placeholder-label {\n  position: absolute;\n  top: 40%;\n  transform: translateY(-50%);\n  left: 2%;\n  pointer-events: none;\n  font-size: 15px;\n  color: white;\n  font-weight: 600;\n  background: #0d00ff;\n  text-transform: uppercase;\n  padding: 3px 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvcmFyaW8tc2VsZWNpb25hZG8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsWUFBQTtBQUNGOztBQUVBO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0EsMkJBQUE7RUFDQSxRQUFBO0VBQ0Esb0JBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtFQUNBLGNBQUE7QUFDRiIsImZpbGUiOiJob3JhcmlvLXNlbGVjaW9uYWRvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbInN0cm9uZyB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBmb250LXNpemU6IDE5cHg7XG59XG5cbi5pbnB1dC1jb250YWluZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi5kYXRlLWlucHV0IHtcbiAgcGFkZGluZzogNXB4O1xufVxuXG4ucGxhY2Vob2xkZXItbGFiZWwge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNDAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG4gIGxlZnQ6IDIlO1xuICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGJhY2tncm91bmQ6ICMwZDAwZmY7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIHBhZGRpbmc6IDNweCAwO1xufVxuIl19 */";

/***/ }),

/***/ 7216:
/*!**************************************************************************************!*\
  !*** ./src/app/paginas/horario-selecionado/horario-selecionado.page.html?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header></app-header>\n\n<ion-content>\n  <section class=\"main-area text-center\">\n    <div class=\"titulo-local\">\n      <div class=\"texto\">Confirme as Informações</div>\n      <div class=\"icon-marca\">\n        <img src=\"assets/images/marca/elemento-branco.png\" alt=\"elemento\">\n      </div>\n    </div>\n\n    <div id=\"cadastro\">\n      <div *ngIf=\"!cadastro\">\n        <div id=\"escolha\">\n          <div class=\"escolha-confirmacao\">\n            <div class=\"titulo\">Especialidade</div>\n            <div class=\"informacao\">{{especialidade?.especialidade}}</div>\n          </div>\n\n          <div class=\"escolha-confirmacao\">\n            <div class=\"titulo\">Profissional</div>\n            <div class=\"informacao\">{{profissional?.nome}}</div>\n          </div>\n\n          <div *ngFor=\"let profissionais_horarios_disponibilidade of profissionais_horarios_disponibilidades\">\n            <div class=\"itens\">\n              <div class=\"escolha-confirmacao\">\n                <div class=\"titulo\">Data</div>\n                <div class=\"informacao\">{{profissionais_horarios_disponibilidade?.data | date: 'dd/MM'}}</div>\n              </div>\n\n              <div class=\"escolha-confirmacao\">\n                <div class=\"titulo\">Hora</div>\n                <div class=\"informacao\">{{profissionais_horarios_disponibilidade?.hr_inicio}}</div>\n              </div>\n            </div>\n\n            <div class=\"escolha-confirmacao\" style=\"background-color: #0d00ff;\">\n              <div class=\"titulo\" style=\"background-color: #ff7400;\">Unidade</div>\n              <div class=\"informacao\">{{profissionais_horarios_disponibilidade?.consultorio}}</div>\n            </div>\n          </div>\n        </div>\n\n        <div id=\"informe-cpf\">\n          <div class=\"form-group\">\n            <div class=\"dados-paciente\">\n              Informe o CPF do paciente e CLIQUE em <br>\n              <b>confirmar</b> para fazer o agendamento.\n            </div>\n\n            <input type=\"text\" [(ngModel)]=\"cpf\" class=\"box\" id=\"cpf\" name=\"cpf\" [patterns]=\"customPatterns\" mask=\"000.000.000-00\" placeholder=\"Digite seu CPF\">\n            <div class=\"icon-input\">\n              <img src=\"assets/images/perfil/65937.png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"actions text-center\">\n            <button type=\"button\" class=\"btn btn-warning\" (click)=\"buscaCPF()\">Confirmar</button>\n          </div>\n        </div>\n\n        <div *ngIf=\"mensagem\" class=\"alert alert-warning\" style=\"margin-top: 20px;\">\n          <div [innerHTML]=\"mensagem\" ></div>\n          <div *ngIf=\"naoEncontrado()\">\n            Vamos iniciar o seu cadastro ? <br>\n            <button class=\"btn btn-primary\" (click)=\"telaSalvarCadastro()\">Clique aqui para iniciar</button>\n          </div>\n        </div>\n\n        <div id=\"dadosPaciente\" *ngIf=\"paciente && paciente.id && paciente.id > 0 && paciente.cep\" style=\"padding-top: 20px;\">\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.nome\" class=\"box\" id=\"nome\" name=\"nome\" placeholder=\"Digite seu nome\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/name.png\" alt=\"name\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.rg\" [patterns]=\"customPatterns\" mask=\"00.000.000-00\" class=\"box\"\n              id=\"rg\" name=\"rg\" placeholder=\"Digite seu RG\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/65937.png\" alt=\"65937\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <select [(ngModel)]=\"paciente.sexo\" class=\"box\" id=\"sexo\" name=\"sexo\">\n              <option value=\"0\">Sexo</option>\n              <option value=\"1\">Feminino</option>\n              <option value=\"2\">Masculino</option>\n            </select>\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/505972.png\" alt=\"505972\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.nome_mae\" class=\"box\" name=\"nome_mae\" id=\"nome_mae\"\n              placeholder=\"Digite nome da mãe\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/3557853.png\" alt=\"3557853\">\n            </div>\n          </div>\n\n          <div class=\"form-group input-container\">\n            <input readonly type=\"date\" [(ngModel)]=\"paciente.data_nascimento\" class=\"box\" name=\"data_nascimento\" id=\"data_nascimento\">\n\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/2458562.png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.fone\" class=\"box\" [patterns]=\"customPatterns\"\n              mask=\"(00) 00000-0000\" id=\"fone\" name=\"fone\" placeholder=\"Digite seu telefone\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/celular.png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.fone2\" class=\"box\" [patterns]=\"customPatterns\"\n              mask=\"(00) 00000-0000\" id=\"fone2\" name=\"fone2\" placeholder=\"Digite seu telefone 2\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/celular.png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.cep\" name=\"cep\" (blur)=\"preencheCep()\" [patterns]=\"customPatterns\" mask=\"00000-000\" class=\"box\"\n              id=\"cep\" placeholder=\"Digite seu CEP\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.endereco\" name=\"endereco\" class=\"box\" id=\"endereco\"\n              placeholder=\"Digite seu endereço\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.numero\" name=\"numero\" maxlength=\"10\" class=\"box\" id=\"numero\"\n              placeholder=\"Digite seu número\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.bairro\" name=\"bairro\" class=\"box\" id=\"bairro\" placeholder=\"Digite seu bairro\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.cidade\" name=\"cidade\" class=\"box\" id=\"cidade\" placeholder=\"Digite seu cidade\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <input readonly type=\"text\" [(ngModel)]=\"paciente.uf\" name=\"uf\" class=\"box\" id=\"uf\" placeholder=\"Digite seu estado\">\n            <div class=\"icon-input register-icon\">\n              <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n            </div>\n          </div>\n\n          <div id=\"mensagemErro\" *ngIf=\"mensagem_cadastro\" [innerHTML]=\"mensagem_cadastro\" class=\"alert alert-warning\"\n            style=\"margin-top: 20px;\"></div>\n\n          <div class=\"actions text-center add-carrinho\" (click)=\"addCarrinho()\">\n            <button type=\"button\" class=\"btn btn-warning\">Adicione ao Carrinho</button>\n            <div class=\"icon-flutuante\">\n              <img src=\"assets/images/perfil/icon-carrinho-de-compras-de-design-xadrez.png\" alt=\"\">\n            </div>\n          </div>\n        </div>\n      </div>\n\n      <div *ngIf=\"cadastro\">\n        <h1>Informar dados do paciente</h1>\n        <br>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.nome\" class=\"box\" id=\"nome\" name=\"name\" placeholder=\"Nome Completo\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/name.png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.rg\" [patterns]=\"customPatterns\" mask=\"00.000.000-00\" class=\"box\"\n            id=\"rg\" name=\"rg\" placeholder=\"RG\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/65937.png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <select [(ngModel)]=\"paciente.sexo\" class=\"box\" id=\"sexo\" name=\"sexo\">\n            <option value=\"0\">Sexo</option>\n            <option value=\"1\">Feminino</option>\n            <option value=\"2\">Masculino</option>\n          </select>\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/505972.png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.nome_mae\" class=\"box\" name=\"nome_mae\" id=\"nome_mae\"\n            placeholder=\"NOME DA MÃE\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/3557853.png\" alt=\"3557853\">\n          </div>\n        </div>\n\n        <div class=\"form-group input-container\">\n          <input type=\"date\" [(ngModel)]=\"paciente.data_nascimento\" class=\"box\" name=\"data_nascimento\" id=\"data_nascimento\" (click)=\"removePlaceholderDate('none')\">\n          <label class=\"placeholder-label\" for=\"dateInput\">Data de Nascimento</label>\n\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/2458562.png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.fone\" class=\"box\" [patterns]=\"customPatterns\"\n            mask=\"(00) 00000-0000\" id=\"fone\" name=\"fone\" placeholder=\"Telefone/Whatsapp\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/celular.png\" alt=\"celular\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.fone2\" class=\"box\" [patterns]=\"customPatterns\"\n            mask=\"(00) 00000-0000\" id=\"fone2\" name=\"fone2\" placeholder=\"Telefone/Whatsapp\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/celular.png\" alt=\"celular\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.cep\" name=\"cep\" (blur)=\"preencheCep()\" [patterns]=\"customPatterns\" mask=\"00000-000\" class=\"box\"\n            id=\"cep\" placeholder=\"CEP\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.endereco\" name=\"endereco\" class=\"box\" id=\"endereco\"\n            placeholder=\"Endereço\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.numero\" name=\"numero\" maxlength=\"10\" class=\"box\" id=\"numero\"\n            placeholder=\"Número\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.bairro\" name=\"bairro\" class=\"box\" id=\"bairro\" placeholder=\"Bairro\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.cidade\" name=\"cidade\" class=\"box\" id=\"cidade\" placeholder=\"Cidade\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <input type=\"text\" [(ngModel)]=\"paciente.uf\" name=\"uf\" class=\"box\" id=\"uf\" placeholder=\"Estado\">\n          <div class=\"icon-input register-icon\">\n            <img src=\"assets/images/perfil/address--v1-(1).png\" alt=\"\">\n          </div>\n        </div>\n\n        <div id=\"mensagemErro\" *ngIf=\"mensagem_cadastro\" [innerHTML]=\"mensagem_cadastro\" class=\"alert alert-warning\"\n            style=\"margin-top: 20px;\"></div>\n\n        <br>\n\n        <div class=\"actions text-center\">\n          <button type=\"button\" class=\"btn btn-warning\" style=\"padding: 5px 33px; margin-bottom: 10px;\" (click)=\"cadastrar()\">Salvar</button><br>\n          <button type=\"button\" class=\"btn btn-primary\" (click)=\"voltar()\">Cancelar</button>\n        </div>\n      </div>\n    </div>\n  </section>\n</ion-content>\n\n<app-footer></app-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_paginas_horario-selecionado_horario-selecionado_module_ts.js.map