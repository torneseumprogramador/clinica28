"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_paginas_profissional-selecionado_profissional-selecionado_module_ts"],{

/***/ 4300:
/*!*********************************************************************************************!*\
  !*** ./src/app/paginas/profissional-selecionado/profissional-selecionado-routing.module.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfissionalSelecionadoPageRoutingModule": () => (/* binding */ ProfissionalSelecionadoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _profissional_selecionado_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profissional-selecionado.page */ 5969);




const routes = [
    {
        path: '',
        component: _profissional_selecionado_page__WEBPACK_IMPORTED_MODULE_0__.ProfissionalSelecionadoPage
    }
];
let ProfissionalSelecionadoPageRoutingModule = class ProfissionalSelecionadoPageRoutingModule {
};
ProfissionalSelecionadoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProfissionalSelecionadoPageRoutingModule);



/***/ }),

/***/ 4129:
/*!*************************************************************************************!*\
  !*** ./src/app/paginas/profissional-selecionado/profissional-selecionado.module.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfissionalSelecionadoPageModule": () => (/* binding */ ProfissionalSelecionadoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _profissional_selecionado_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profissional-selecionado-routing.module */ 4300);
/* harmony import */ var _profissional_selecionado_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profissional-selecionado.page */ 5969);
/* harmony import */ var src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/componentes/header/header.component */ 4944);
/* harmony import */ var src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/componentes/footer/footer.component */ 202);
/* harmony import */ var src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/componentes/carrinho/carrinho.component */ 8752);










let ProfissionalSelecionadoPageModule = class ProfissionalSelecionadoPageModule {
};
ProfissionalSelecionadoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _profissional_selecionado_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProfissionalSelecionadoPageRoutingModule
        ],
        declarations: [_profissional_selecionado_page__WEBPACK_IMPORTED_MODULE_1__.ProfissionalSelecionadoPage,
            src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_2__.HeaderComponent, src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterComponent, src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_4__.CarrinhoComponent,
        ]
    })
], ProfissionalSelecionadoPageModule);



/***/ }),

/***/ 5969:
/*!***********************************************************************************!*\
  !*** ./src/app/paginas/profissional-selecionado/profissional-selecionado.page.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfissionalSelecionadoPage": () => (/* binding */ ProfissionalSelecionadoPage)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _profissional_selecionado_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profissional-selecionado.page.html?ngResource */ 9315);
/* harmony import */ var _profissional_selecionado_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./profissional-selecionado.page.scss?ngResource */ 5997);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_services_especialidadeService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/especialidadeService */ 2930);
/* harmony import */ var src_app_services_procedimentoService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/procedimentoService */ 3247);
/* harmony import */ var src_app_services_profissionalService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/profissionalService */ 5268);










let ProfissionalSelecionadoPage = class ProfissionalSelecionadoPage {
  constructor(http, router, routerParams) {
    this.http = http;
    this.router = router;
    this.routerParams = routerParams;
    this.procedimentos = [];
    this.msg_procedimentos = "";
  }

  ngOnInit() {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.especialidade = yield new src_app_services_especialidadeService__WEBPACK_IMPORTED_MODULE_3__.EspecialidadeServico(_this.http).get(_this.routerParams.snapshot.params.especialidade_id);
      _this.profissional = yield new src_app_services_profissionalService__WEBPACK_IMPORTED_MODULE_5__.ProfissionalServico(_this.http).get(_this.routerParams.snapshot.params.profissional_id);
      yield _this.carregaProcedimentos();
    })();
  }

  carregaProcedimentos() {
    var _this2 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.profissional = _this2.profissional;
      _this2.procedimentos = yield new src_app_services_procedimentoService__WEBPACK_IMPORTED_MODULE_4__.ProcedimentoServico(_this2.http).porProfissional(_this2.profissional.id);
      _this2.msg_procedimentos = _this2.procedimentos.length == 0 ? "Nenhum procedimento encontrado" : "";
    })();
  }

  carregaHorarios(procedimento) {
    var _this3 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.router.navigateByUrl(`/especialidade/${_this3.especialidade.id}/profissional/${_this3.profissional.id}/procedimento/${procedimento.id}`);
    })();
  }

};

ProfissionalSelecionadoPage.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute
}];

ProfissionalSelecionadoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-profissional-selecionado',
  template: _profissional_selecionado_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_profissional_selecionado_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ProfissionalSelecionadoPage);


/***/ }),

/***/ 5997:
/*!************************************************************************************************!*\
  !*** ./src/app/paginas/profissional-selecionado/profissional-selecionado.page.scss?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcm9maXNzaW9uYWwtc2VsZWNpb25hZG8ucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 9315:
/*!************************************************************************************************!*\
  !*** ./src/app/paginas/profissional-selecionado/profissional-selecionado.page.html?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header></app-header>\n\n<ion-content [fullscreen]=\"true\">\n  <section class=\"main-area\">\n    <div style=\"display: inline-block;text-align:center;width:100%\">\n      <h1>Você escolheu: </h1>\n        <ul style=\"font-size: 16px;list-style-type: none;;\">\n        <li><b>Especialidade:</b> {{especialidade?.especialidade}}</li>\n        <li><b>Profissional:</b> {{profissional?.nome}}</li>\n      </ul>\n      <hr>\n    </div>\n\n    <div id=\"procedimentos\">\n      <div *ngIf=\"msg_procedimentos\" class=\"alert alert-warning\">{{msg_procedimentos}}</div>\n      <div *ngIf=\"procedimentos && procedimentos.length > 0\">\n        <p>Escolha o Procedimento:</p>\n        <table class=\"table\">\n          <thead>\n            <tr>\n              <th scope=\"col\">Nome</th>\n              <th scope=\"col\">Valor</th>\n              <th scope=\"col\"></th>\n            </tr>\n          </thead>\n          <tbody>\n            <tr *ngFor=\"let procedimento of procedimentos\">\n              <td>{{procedimento.procedimento}}</td>\n              <td>{{procedimento.valor_procedimento | currency : 'BRL'}}</td>\n              <td style=\"text-align: right;\">\n                <button class=\"btn btn-primary\" (click)=\"carregaHorarios(procedimento)\">\n                  Selecionar\n                </button>\n              </td>\n            </tr>\n          </tbody>\n        </table>\n      </div>\n    </div>\n  </section>\n</ion-content>\n\n<app-footer></app-footer>";

/***/ })

}]);
//# sourceMappingURL=src_app_paginas_profissional-selecionado_profissional-selecionado_module_ts.js.map