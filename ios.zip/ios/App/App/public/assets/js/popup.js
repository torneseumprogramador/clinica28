let custonPopup = {}
custonPopup.modal = document.querySelector('.modal-popup');
custonPopup.open = (imagem, numPopup) => {
    const imgPopup = document.querySelector(".img-popup")
    imgPopup.src = imagem

    localStorage.setItem('popup', JSON.stringify(numPopup))

    custonPopup.modal.isOpen = true
}

custonPopup.close = () => {
    custonPopup.modal.isOpen = false
}

