let custonModal = {}
custonModal.modal = document.querySelector('.modal-system');
custonModal.open = (titulo, texto, textoBotao, carrinho, forceCloseModalShow) => {
  document.getElementById("modalTitulo").innerHTML = titulo
  document.getElementById("modalText").innerHTML = texto
  document.getElementById("btnFim").innerHTML = textoBotao

  if(titulo.includes('carrinho')){
    document.querySelector(".area-carrinho").style.display = "block"
  }

  if(carrinho) document.querySelector("#formModal .area-carrinho").style="display:block"
  else document.querySelector("#formModal .area-carrinho").style="display:none"

  if(forceCloseModalShow) document.querySelector(".force-close.button-modal").style="display:block"
  else document.querySelector(".force-close.button-modal").style="display:none"

  custonModal.modal.isOpen = true
}

custonModal.forceClose = () => {
  custonModal.modal.isOpen = false
}

custonModal.close = () => {
    try{ if(custonModal.callback) custonModal.callback.call(); custonModal.callback = undefined; } catch (e){}
    custonModal.modal.isOpen = false
}

custonModal.changeRouter = () => {
  window.location.href = `/carrinho`;
  custonModal.modal.isOpen = false
}
