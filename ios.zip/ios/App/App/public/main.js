(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 124);



const routes = [
    {
        path: 'home',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_home_home_module_ts-src_app_services_modalService_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/home/home.module */ 7317)).then((m) => m.HomePageModule),
        pathMatch: 'full',
    },
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full',
    },
    {
        path: 'carrinho',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("src_app_paginas_carrinho_carrinho_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/carrinho/carrinho.module */ 3926)).then((m) => m.CarrinhoPageModule),
    },
    {
        path: 'pagamento',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("default-node_modules_ngx-mask_fesm2020_ngx-mask_mjs"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_pagamento_pagamento_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/pagamento/pagamento.module */ 5052)).then((m) => m.PagamentoPageModule),
    },
    {
        path: 'sucesso',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("src_app_paginas_sucesso_sucesso_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/sucesso/sucesso.module */ 5438)).then((m) => m.SucessoPageModule),
    },
    {
        path: 'minhas-compras',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("default-src_app_componentes_carrinho_carrinho_component_ts-src_app_componentes_footer_footer_-efbff1"), __webpack_require__.e("src_app_paginas_minhas-compras_minhas-compras_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/minhas-compras/minhas-compras.module */ 2467)).then((m) => m.MinhasComprasPageModule),
    },
    {
        path: 'meus-atendimentos',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("src_app_paginas_meus-atendimentos_meus-atendimentos_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/meus-atendimentos/meus-atendimentos.module */ 6717)).then((m) => m.MeusAtendimentosPageModule),
    },
    {
        path: 'meus-orcamentos',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("default-src_app_componentes_carrinho_carrinho_component_ts-src_app_componentes_footer_footer_-45d936"), __webpack_require__.e("src_app_paginas_meus-orcamentos_meus-orcamentos_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/meus-orcamentos/meus-orcamentos.module */ 9012)).then((m) => m.MeusOrcamentosPageModule),
    },
    {
        path: 'meus-exames',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("src_app_paginas_meus-exames_meus-exames_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/meus-exames/meus-exames.module */ 9593)).then((m) => m.MeusExamesPageModule),
    },
    {
        path: 'minhas-compras/:pedido_id/detalhes',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("default-src_app_componentes_carrinho_carrinho_component_ts-src_app_componentes_footer_footer_-efbff1"), __webpack_require__.e("src_app_paginas_minhas-compras-detalhes_minhas-compras-detalhes_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/minhas-compras-detalhes/minhas-compras-detalhes.module */ 9060)).then((m) => m.MinhasComprasDetalhesPageModule),
    },
    {
        path: 'login',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_ngx-mask_fesm2020_ngx-mask_mjs"), __webpack_require__.e("default-src_app_componentes_termos-uso_termos-uso_component_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_login_login_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/login/login.module */ 5099)).then((m) => m.LoginPageModule),
    },
    {
        path: 'perfil',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("default-node_modules_ngx-mask_fesm2020_ngx-mask_mjs"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_perfil_perfil_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/perfil/perfil.module */ 660)).then((m) => m.PerfilPageModule),
    },
    {
        path: 'home',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_home_home_module_ts-src_app_services_modalService_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/home/home.module */ 7317)).then((m) => m.HomePageModule),
    },
    {
        path: 'agendamentos',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("default-src_app_componentes_carrinho_carrinho_component_ts-src_app_componentes_footer_footer_-5ed14a"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_agendamento_agendamento_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/agendamento/agendamento.module */ 8314)).then((m) => m.AgendamentoPageModule),
    },
    {
        path: 'especialidade/:especialidade_id/profissional/:profissional_id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("default-src_app_componentes_carrinho_carrinho_component_ts-src_app_componentes_footer_footer_-5ed14a"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_profissional-selecionado_profissional-selecionado_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/profissional-selecionado/profissional-selecionado.module */ 4129)).then((m) => m.ProfissionalSelecionadoPageModule),
    },
    {
        path: 'especialidade/:especialidade_id/profissional/:profissional_id/procedimento-grupo/:grupo_id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("default-src_app_componentes_carrinho_carrinho_component_ts-src_app_componentes_footer_footer_-5ed14a"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_procedimento-selecionado_procedimento-selecionado_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/procedimento-selecionado/procedimento-selecionado.module */ 2479)).then((m) => m.ProcedimentoSelecionadoPageModule),
    },
    {
        path: 'especialidade/:especialidade_id/profissional/:profissional_id/procedimento/:procedimento_id/horario-selecionado/:profissionais_horarios_disponibilidade_id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("default-node_modules_ngx-mask_fesm2020_ngx-mask_mjs"), __webpack_require__.e("default-src_app_componentes_carrinho_carrinho_component_ts-src_app_componentes_footer_footer_-5ed14a"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_horario-selecionado_horario-selecionado_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/horario-selecionado/horario-selecionado.module */ 111)).then((m) => m.HorarioSelecionadoPageModule),
    },
    {
        path: 'procedimentos-externos',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("default-src_app_componentes_carrinho_carrinho_component_ts-src_app_componentes_footer_footer_-45d936"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_procedimentos-externos_procedimentos-externos_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/procedimentos-externos/procedimentos-externos.module */ 9220)).then((m) => m.ProcedimentosExternosPageModule),
    },
    {
        path: 'procedimentos-externos/selecionados',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("default-node_modules_ngx-mask_fesm2020_ngx-mask_mjs"), __webpack_require__.e("default-src_app_componentes_carrinho_carrinho_component_ts-src_app_componentes_footer_footer_-45d936"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_procedimentos-externos-selecionados_procedimentos-externos-selecionados_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/procedimentos-externos-selecionados/procedimentos-externos-selecionados.module */ 5630)).then((m) => m.ProcedimentosExternosSelecionadosPageModule),
    },
    {
        path: 'conta',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("src_app_paginas_conta_conta_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/conta/conta.module */ 582)).then((m) => m.ContaPageModule),
    },
    {
        path: 'meus-agendamentos',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("default-src_app_componentes_carrinho_carrinho_component_ts-src_app_componentes_footer_footer_-efbff1"), __webpack_require__.e("src_app_paginas_meus-agendamentos_meus-agendamentos_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/meus-agendamentos/meus-agendamentos.module */ 822)).then((m) => m.MeusAgendamentosPageModule),
    },
    {
        path: 'contato',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("src_app_paginas_contato_contato_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/contato/contato.module */ 8949)).then((m) => m.ContatoPageModule),
    },
    {
        path: 'onde-estamos',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("src_app_paginas_onde-estamos_onde-estamos_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/onde-estamos/onde-estamos.module */ 3016)).then((m) => m.OndeEstamosPageModule),
    },
    {
        path: 'termos',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("default-src_app_componentes_termos-uso_termos-uso_component_ts"), __webpack_require__.e("src_app_paginas_termos_termos_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/termos/termos.module */ 9138)).then((m) => m.TermosPageModule),
    },
    {
        path: 'procedimentos-orcamentos',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("default-src_app_componentes_carrinho_carrinho_component_ts-src_app_componentes_footer_footer_-45d936"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_procedimentos-orcamentos_procedimentos-orcamentos_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/procedimentos-orcamentos/procedimentos-orcamentos.module */ 4660)).then((m) => m.ProcedimentosOrcamentosPageModule),
    },
    {
        path: 'exame-citologico',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("src_app_paginas_exame-citologico_exame-citologico_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/exame-citologico/exame-citologico.module */ 6084)).then((m) => m.ExameCitologicoPageModule),
    },
    {
        path: 'profissional/login',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_ngx-mask_fesm2020_ngx-mask_mjs"), __webpack_require__.e("default-src_app_componentes_termos-uso_termos-uso_component_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_profissional_login_login_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/profissional/login/login.module */ 7178)).then((m) => m.LoginPageModule),
    },
    {
        path: 'profissional/home',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("default-src_app_componentes_profissional-footer_profissional-footer_component_ts-src_app_comp-b81eb3"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_profissional_home_home_module_ts-src_app_services_modalService_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/profissional/home/home.module */ 2756)).then((m) => m.HomePageModule),
    },
    {
        path: 'profissional/meus-agendamentos',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_componentes_profissional-footer_profissional-footer_component_ts-src_app_comp-b81eb3"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_profissional_agendamento_agendamento_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/profissional/agendamento/agendamento.module */ 3710)).then((m) => m.AgendamentoPageModule),
    },
    {
        path: 'profissional/disponibilidades',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_componentes_profissional-footer_profissional-footer_component_ts-src_app_comp-b81eb3"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_profissional_disponibilidades_disponibilidades_module_ts-src_app_services_loa-62015f")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/profissional/disponibilidades/disponibilidades.module */ 9953)).then((m) => m.DisponibilidadesPageModule),
    },
    {
        path: 'profissional/conta',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_carrinho_service_ts"), __webpack_require__.e("default-src_app_componentes_profissional-footer_profissional-footer_component_ts-src_app_comp-b81eb3"), __webpack_require__.e("src_app_paginas_profissional_conta_conta_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/profissional/conta/conta.module */ 2056)).then((m) => m.ContaPageModule),
    },
    {
        path: 'profissional/perfil',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_ngx-mask_fesm2020_ngx-mask_mjs"), __webpack_require__.e("default-src_app_componentes_profissional-footer_profissional-footer_component_ts-src_app_comp-b81eb3"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_profissional_perfil_perfil_module_ts-src_app_services_loadService_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/profissional/perfil/perfil.module */ 4479)).then((m) => m.PerfilPageModule),
    },
    {
        path: 'profissional/locais-atendimentos',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_componentes_profissional-footer_profissional-footer_component_ts-src_app_comp-b81eb3"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_profissional_locais-atendimentos_locais-atendimentos_module_ts-src_app_servic-e3a3cb")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/profissional/locais-atendimentos/locais-atendimentos.module */ 9277)).then((m) => m.LocaisAtendimentosPageModule),
    },
    {
        path: 'profissional/dias-atendimentos',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_componentes_profissional-footer_profissional-footer_component_ts-src_app_comp-b81eb3"), __webpack_require__.e("common"), __webpack_require__.e("src_app_paginas_profissional_dias-atendimentos_dias-atendimentos_module_ts-src_app_services_l-4cd74b")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/profissional/dias-atendimentos/dias-atendimentos.module */ 3231)).then((m) => m.DiasAtendimentosPageModule),
    },
    {
        path: 'profissional/pacientes/:paciente_id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_ngx-mask_fesm2020_ngx-mask_mjs"), __webpack_require__.e("default-src_app_componentes_profissional-footer_profissional-footer_component_ts-src_app_comp-b81eb3"), __webpack_require__.e("src_app_paginas_profissional_pacientes_pacientes_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./paginas/profissional/pacientes/pacientes.module */ 6318)).then((m) => m.PacientesPageModule),
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__.PreloadAllModules }),
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule],
        declarations: [],
    })
], AppRoutingModule);



/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component.html?ngResource */ 3383);
/* harmony import */ var _app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss?ngResource */ 9259);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);




let AppComponent = class AppComponent {
    constructor() { }
};
AppComponent.ctorParameters = () => [];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-root',
        template: _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AppComponent);



/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/platform-browser */ 4497);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _coreui_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @coreui/angular */ 3415);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 158);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_common_locales_pt__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/locales/pt */ 7423);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _pipes_formata_cpf_pipe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pipes/formata-cpf.pipe */ 5601);
/* harmony import */ var _pipes_formata_rg_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pipes/formata-rg.pipe */ 8088);
/* harmony import */ var _pipes_formata_sexo_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pipes/formata-sexo.pipe */ 1089);
/* harmony import */ var _pipes_formata_telefone_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pipes/formata-telefone.pipe */ 683);
















(0,_angular_common__WEBPACK_IMPORTED_MODULE_6__.registerLocaleData)(_angular_common_locales_pt__WEBPACK_IMPORTED_MODULE_7__["default"]);
let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.NgModule)({
        declarations: [
            _app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent,
            _pipes_formata_sexo_pipe__WEBPACK_IMPORTED_MODULE_4__.FormataSexoPipe, _pipes_formata_cpf_pipe__WEBPACK_IMPORTED_MODULE_2__.FormataCpfPipe, _pipes_formata_rg_pipe__WEBPACK_IMPORTED_MODULE_3__.FormataRgPipe, _pipes_formata_telefone_pipe__WEBPACK_IMPORTED_MODULE_5__.FormataTelefonePipe
        ],
        exports: [
            _pipes_formata_sexo_pipe__WEBPACK_IMPORTED_MODULE_4__.FormataSexoPipe, _pipes_formata_cpf_pipe__WEBPACK_IMPORTED_MODULE_2__.FormataCpfPipe, _pipes_formata_rg_pipe__WEBPACK_IMPORTED_MODULE_3__.FormataRgPipe, _pipes_formata_telefone_pipe__WEBPACK_IMPORTED_MODULE_5__.FormataTelefonePipe
        ],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__.BrowserModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonicModule.forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_12__.HttpClientModule, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormsModule,
            _coreui_angular__WEBPACK_IMPORTED_MODULE_14__.AlertModule
        ],
        providers: [
            { provide: _angular_core__WEBPACK_IMPORTED_MODULE_9__.LOCALE_ID, useValue: 'pt' },
            {
                provide: _angular_core__WEBPACK_IMPORTED_MODULE_9__.DEFAULT_CURRENCY_CODE,
                useValue: 'BRL',
            },
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_15__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonicRouteStrategy }
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 5601:
/*!*******************************************!*\
  !*** ./src/app/pipes/formata-cpf.pipe.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormataCpfPipe": () => (/* binding */ FormataCpfPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);


let FormataCpfPipe = class FormataCpfPipe {
    transform(cpf) {
        cpf = cpf.replace(/[^\d]/g, "");
        return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");
    }
};
FormataCpfPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'formataCPF'
    })
], FormataCpfPipe);



/***/ }),

/***/ 8088:
/*!******************************************!*\
  !*** ./src/app/pipes/formata-rg.pipe.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormataRgPipe": () => (/* binding */ FormataRgPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);


let FormataRgPipe = class FormataRgPipe {
    transform(rg) {
        rg = rg.replace(/[^\d]/g, "");
        return rg.replace(/(\d{2})(\d{3})(\d{3})(\d{1})/, "$1.$2.$3-$4");
    }
};
FormataRgPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'formataRG'
    })
], FormataRgPipe);



/***/ }),

/***/ 1089:
/*!********************************************!*\
  !*** ./src/app/pipes/formata-sexo.pipe.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormataSexoPipe": () => (/* binding */ FormataSexoPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);


let FormataSexoPipe = class FormataSexoPipe {
    transform(sexo) {
        return sexo == 1 ? "Feminino" : "Masculino";
    }
};
FormataSexoPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'formataSexo'
    })
], FormataSexoPipe);



/***/ }),

/***/ 683:
/*!************************************************!*\
  !*** ./src/app/pipes/formata-telefone.pipe.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormataTelefonePipe": () => (/* binding */ FormataTelefonePipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);


let FormataTelefonePipe = class FormataTelefonePipe {
    transform(telefone) {
        telefone = telefone.replace(/[^\d]/g, "");
        telefone = telefone.replace(/(\d{2})(\d{5})(\d{4})/, "($1) $2-$3");
        if (telefone.match(/-/) == null) {
            telefone = telefone.replace(/(\d{2})(\d{4})(\d{4})/, "($1) $2-$3");
        }
        return telefone;
    }
};
FormataTelefonePipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'formataTelefone'
    })
], FormataTelefonePipe);



/***/ }),

/***/ 2340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
const environment = {
    production: false,
    API: 'https://novo-clinica-api-f0c1c2456b64.herokuapp.com/',
    iugu_pg_id: '0CB677CD5D024435B139911CE98CDC20',
};


/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 6057);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 2340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		79,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		5593,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		3225,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		2893,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		6655,
		"common",
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		4856,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		3059,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		8648,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		8308,
		"common",
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		4690,
		"common",
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		4090,
		"common",
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		6214,
		"common",
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		9447,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		9689,
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		8840,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		749,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		9667,
		"common",
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		3288,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		5473,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		3634,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		2855,
		"common",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		495,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		8737,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		9632,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		4446,
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		2275,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		8050,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		8994,
		"common",
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		3592,
		"common",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		5454,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		290,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		2666,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		4816,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		5534,
		"common",
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		4902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		1938,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		8179,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		668,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		1624,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		9989,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		8902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		199,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		8395,
		"common",
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		6357,
		"common",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		8268,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		2312,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		2875,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 9259:
/*!***********************************************!*\
  !*** ./src/app/app.component.scss?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 3383:
/*!***********************************************!*\
  !*** ./src/app/app.component.html?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-app>\n  <ion-router-outlet></ion-router-outlet>\n</ion-app>\n";

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map