"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_paginas_agendamento_agendamento_module_ts"],{

/***/ 1190:
/*!*******************************************************************!*\
  !*** ./src/app/paginas/agendamento/agendamento-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgendamentoPageRoutingModule": () => (/* binding */ AgendamentoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _agendamento_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./agendamento.page */ 1382);




const routes = [
    {
        path: '',
        component: _agendamento_page__WEBPACK_IMPORTED_MODULE_0__.AgendamentoPage,
    }
];
let AgendamentoPageRoutingModule = class AgendamentoPageRoutingModule {
};
AgendamentoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], AgendamentoPageRoutingModule);



/***/ }),

/***/ 8314:
/*!***********************************************************!*\
  !*** ./src/app/paginas/agendamento/agendamento.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgendamentoPageModule": () => (/* binding */ AgendamentoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _agendamento_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./agendamento-routing.module */ 1190);
/* harmony import */ var src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/componentes/header/header.component */ 4944);
/* harmony import */ var src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/componentes/footer/footer.component */ 202);
/* harmony import */ var src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/componentes/carrinho/carrinho.component */ 8752);
/* harmony import */ var _agendamento_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./agendamento.page */ 1382);










let AgendamentoPageModule = class AgendamentoPageModule {
};
AgendamentoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _agendamento_routing_module__WEBPACK_IMPORTED_MODULE_0__.AgendamentoPageRoutingModule
        ],
        declarations: [
            src_app_componentes_header_header_component__WEBPACK_IMPORTED_MODULE_1__.HeaderComponent, src_app_componentes_footer_footer_component__WEBPACK_IMPORTED_MODULE_2__.FooterComponent, src_app_componentes_carrinho_carrinho_component__WEBPACK_IMPORTED_MODULE_3__.CarrinhoComponent,
            _agendamento_page__WEBPACK_IMPORTED_MODULE_4__.AgendamentoPage
        ]
    })
], AgendamentoPageModule);



/***/ }),

/***/ 1382:
/*!*********************************************************!*\
  !*** ./src/app/paginas/agendamento/agendamento.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgendamentoPage": () => (/* binding */ AgendamentoPage)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _agendamento_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./agendamento.page.html?ngResource */ 679);
/* harmony import */ var _agendamento_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./agendamento.page.scss?ngResource */ 641);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_services_carrinho_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/carrinho.service */ 2136);
/* harmony import */ var src_app_services_especialidadeService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/especialidadeService */ 2930);
/* harmony import */ var src_app_services_formaAtendimentoService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/formaAtendimentoService */ 7187);
/* harmony import */ var src_app_services_localConsultaService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/localConsultaService */ 2417);
/* harmony import */ var src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/pacienteService */ 8839);
/* harmony import */ var src_app_services_profissionalCidadeService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/profissionalCidadeService */ 4427);
/* harmony import */ var src_app_services_profissionalService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/profissionalService */ 5268);














let AgendamentoPage = class AgendamentoPage {
  constructor(http, route, routerParams, router, carrinhoService) {
    this.http = http;
    this.routerParams = routerParams;
    this.router = router;
    this.carrinhoService = carrinhoService;
    this.especialidade_id = 0;
    this.atendimento_id = 0;
    this.cidade = '';
    this.msg_profissional = '';
    this.cidades = [];
    this.atendimentos = [];
    this.especialidades = [];
    this.profissionais = [];
    src_app_services_localConsultaService__WEBPACK_IMPORTED_MODULE_6__.LocalConsultaServico.removeLocal();
    route.params.subscribe(val => {
      this.limpaTudo();
      this.carregaEspecialidades();
      this.carrinhoService.carregaQuantidade();
    });

    if (!src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_7__.PacienteServico.logado()) {
      this.router.navigateByUrl('/login');
    }

    this.paciente = src_app_services_pacienteService__WEBPACK_IMPORTED_MODULE_7__.PacienteServico.getSessao();
  }

  ngOnInit() {
    this.limpaTudo();
    this.carregaEspecialidades();
    this.carregaAtendimentos();
    this.carregaCidades();
  }

  limpaTudo() {
    this.profissional = undefined;
    this.especialidades = [];
    this.profissionais = [];
    this.msg_profissional = '';
    this.especialidade_id = 0;
    this.atendimento_id = 0;
    this.cidade = '';
  }

  profissionalSelecionado(profissional) {
    return this.profissional && profissional.id === this.profissional.id ? 'selected' : '';
  }

  carregaEspecialidades() {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.limpaTudo();

      _this.especialidades = yield new src_app_services_especialidadeService__WEBPACK_IMPORTED_MODULE_4__.EspecialidadeServico(_this.http).todos();
    })();
  }

  carregaAtendimentos() {
    var _this2 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.atendimentos = yield new src_app_services_formaAtendimentoService__WEBPACK_IMPORTED_MODULE_5__.FormaAtendimentoServico(_this2.http).todos();
    })();
  }

  carregaCidades() {
    var _this3 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.cidades = yield new src_app_services_profissionalCidadeService__WEBPACK_IMPORTED_MODULE_8__.ProfissionalCidadeServico(_this3.http).todos();
    })();
  }

  carregaProfissionais() {
    var _this4 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this4.atendimento_id == 0 || _this4.atendimento_id > 1 && _this4.cidade === '') {
        _this4.profissionais = [];
        _this4.msg_profissional = '';

        if (_this4.atendimento_id && _this4.atendimento_id > 1) {
          _this4.cidades = yield new src_app_services_profissionalCidadeService__WEBPACK_IMPORTED_MODULE_8__.ProfissionalCidadeServico(_this4.http).todasCidadesPorAtendimentoId(_this4.atendimento_id, _this4.especialidade_id);
        }

        return;
      }

      if (_this4.atendimento_id == 1) {
        _this4.cidade = '';
      }

      _this4.profissionais = yield new src_app_services_profissionalService__WEBPACK_IMPORTED_MODULE_9__.ProfissionalServico(_this4.http).porEspecialidade(_this4.especialidade_id, _this4.atendimento_id, _this4.cidade);
      _this4.msg_profissional = _this4.profissionais.length === 0 && _this4.especialidade_id > 0 ? 'Nenhum profissional encontrado' : '';
    })();
  }

  carregaProcedimentos(profissional) {
    var _this5 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      src_app_services_localConsultaService__WEBPACK_IMPORTED_MODULE_6__.LocalConsultaServico.setLocal({
        tipo: 'consulta',
        profissional: profissional.id,
        especialidade_id: _this5.especialidade_id,
        atendimento_id: _this5.atendimento_id,
        cidade: _this5.cidade
      });

      _this5.router.navigateByUrl(`/especialidade/${_this5.especialidade_id}/profissional/${profissional.id}/procedimento-grupo/1`);
    })();
  }

};

AgendamentoPage.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_10__.HttpClient
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.Router
}, {
  type: src_app_services_carrinho_service__WEBPACK_IMPORTED_MODULE_3__.CarrinhoService
}];

AgendamentoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
  selector: 'app-agendamento',
  template: _agendamento_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_agendamento_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], AgendamentoPage);


/***/ }),

/***/ 7187:
/*!*****************************************************!*\
  !*** ./src/app/services/formaAtendimentoService.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormaAtendimentoServico": () => (/* binding */ FormaAtendimentoServico)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ 2340);
/* harmony import */ var _loadService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./loadService */ 6521);
/* harmony import */ var _pacienteService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pacienteService */ 8839);





class FormaAtendimentoServico {
  constructor(http) {
    this.http = http;
  }

  todos() {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/forma_atendimentos.json`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

}

/***/ }),

/***/ 4427:
/*!*******************************************************!*\
  !*** ./src/app/services/profissionalCidadeService.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfissionalCidadeServico": () => (/* binding */ ProfissionalCidadeServico)
/* harmony export */ });
/* harmony import */ var _Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ 2340);
/* harmony import */ var _loadService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./loadService */ 6521);
/* harmony import */ var _pacienteService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pacienteService */ 8839);





class ProfissionalCidadeServico {
  constructor(http) {
    this.http = http;
  }

  todasCidadesPorAtendimentoId(atendimento_id = 0, especialidade_id = 0) {
    var _this = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/profissional_cidades.json?atendimento_id=${atendimento_id}&especialidade_id=${especialidade_id}`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

  todos() {
    var _this2 = this;

    return (0,_Users_Danilo_projetos_cli28_novo_app_cli28_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.show();

      try {
        const data = yield _this2.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.API}/profissional_cidades.json`, {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            authorization: `Bearer ${_pacienteService__WEBPACK_IMPORTED_MODULE_3__.PacienteServico.token()}`
          })
        }).toPromise();
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        return data;
      } catch (e) {
        _loadService__WEBPACK_IMPORTED_MODULE_2__.LoadService.hide();
        throw e;
      }
    })();
  }

}

/***/ }),

/***/ 641:
/*!**********************************************************************!*\
  !*** ./src/app/paginas/agendamento/agendamento.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFnZW5kYW1lbnRvLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0VBRUEsa0JBQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLFFBQUE7RUFDQSwyQkFBQTtBQUFGOztBQUdBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBQUY7O0FBR0E7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFFQSxjQUFBO0VBRUEsU0FBQTtBQUZGOztBQUtBO0VBQ0UscUJBQUE7QUFGRiIsImZpbGUiOiJhZ2VuZGFtZW50by5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjY29udGFpbmVyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMDtcbiAgcmlnaHQ6IDA7XG4gIHRvcDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG59XG5cbiNjb250YWluZXIgc3Ryb25nIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBsaW5lLWhlaWdodDogMjZweDtcbn1cblxuI2NvbnRhaW5lciBwIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBsaW5lLWhlaWdodDogMjJweDtcblxuICBjb2xvcjogIzhjOGM4YztcblxuICBtYXJnaW46IDA7XG59XG5cbiNjb250YWluZXIgYSB7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbn0iXX0= */";

/***/ }),

/***/ 679:
/*!**********************************************************************!*\
  !*** ./src/app/paginas/agendamento/agendamento.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<app-header></app-header>\n\n<ion-content [fullscreen]=\"true\">\n  <section class=\"main-area text-center\">\n    <div class=\"titulo-local\">\n      <div class=\"texto\">Nossas Especialidades</div>\n      <div class=\"icon-marca\">\n        <img src=\"assets/images/marca/elemento-branco.png\" alt=\"elemento\">\n      </div>\n    </div>\n\n    <div class=\"filtros\">\n      <div>\n        <select [(ngModel)]=\"especialidade_id\" (change)=\"carregaProfissionais()\" class=\"select-area\">\n          <option value=\"0\">[Selecione]</option>\n          <option *ngFor=\"let especialidade of especialidades\" value=\"{{especialidade.id}}\">\n            {{especialidade.especialidade}}</option>\n        </select>\n      </div>\n\n      <div *ngIf=\"especialidade_id\">\n        <br>\n        <p>Atendimento:</p>\n        <select [(ngModel)]=\"atendimento_id\" (change)=\"carregaProfissionais()\" class=\"select-area\">\n          <option value=\"0\">[Selecione]</option>\n          <option *ngFor=\"let atendimento of atendimentos\" value=\"{{atendimento.id}}\">\n            {{atendimento.tipo_atendimento}}</option>\n        </select>\n      </div>\n\n      <div *ngIf=\"especialidade_id && atendimento_id > 1\">\n        <br>\n        <p>Cidades:</p>\n        <select [(ngModel)]=\"cidade\" (change)=\"carregaProfissionais()\" class=\"select-area\">\n          <option value=\"\">[Selecione]</option>\n          <option *ngFor=\"let cidade of cidades\" value=\"{{cidade.cidade}}\">\n            {{cidade.cidade}}</option>\n        </select>\n      </div>\n    </div>\n\n    <div id=\"profissional\">\n      <div *ngIf=\"msg_profissional\" class=\"alert alert-warning\">{{msg_profissional}}</div>\n      <div class=\"profissionais\" *ngIf=\"profissionais && profissionais.length > 0\">\n        <div *ngFor=\"let profissional of profissionais\">\n          <div class=\"profissional\">\n            <div class=\"conteudo\">\n              <div class=\"local\">\n                <div class=\"fonte\">\n                  {{profissional.atendimento_local}} <br>\n                  <div style=\"font-size: 1.1rem;\"> Faixa Etária: De {{profissional.idade_min}} a {{profissional.idade_max}} anos </div>\n                </div>\n                <div class=\"agendar\" (click)=\"carregaProcedimentos(profissional)\">\n                  <div class=\"icon-calendar\">\n                    <img src=\"assets/images/icones/calendario-branco.png\" alt=\"elemento\">\n                  </div>\n                  <div>\n                    <p>Agendar <br> horário</p>\n                  </div>\n                  <div>\n                    <p class=\"valor_procedimento\">{{profissional.valor_procedimento | currency}}</p>\n                  </div>\n                </div>\n              </div>\n\n              <div class=\"dados\">\n                <div class=\"nome\">{{(profissional.nome.length > 25)? (profissional.nome | slice:0:25)+'.':(profissional.nome)}}</div>\n                <div class=\"crm\">{{profissional.crm}}</div>\n              </div>\n            </div>\n\n            <div class=\"icon-image\">\n              <img src=\"{{profissional.imagem}}\" alt=\"elemento\">\n            </div>\n          </div>\n        </div>\n        <br>\n      </div>\n    </div>\n  </section>\n</ion-content>\n\n<app-footer></app-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_paginas_agendamento_agendamento_module_ts.js.map